
import React, { useState, useRef } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { Language } from '../types';
import { DIVINE_ICONS, ANUSHTHAN_INFO } from '../constants';

const VirtualAnushthanPage: React.FC<{ language: Language }> = ({ language }) => {
  const [userName, setUserName] = useState('');
  const [rashi, setRashi] = useState('');
  const [isAnushthanStarted, setIsAnushthanStarted] = useState(false);
  const [offeringCount, setOfferingCount] = useState(0);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  const startAnushthan = () => {
    if (userName.trim()) setIsAnushthanStarted(true);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const receiveBlessing = async () => {
    setIsGeneratingAudio(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
      const prompt = `Give a personalized divine blessing for ${userName} whose Rashi is ${rashi}. Address them as 'Vatsa' (Child). Include a short Sanskrit mantra and a promise of protection from Lord Mahakal. Keep it within 30 words. Language: ${language === 'hi' ? 'Hindi' : 'English'}.`;
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextRef.current) audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const audioBuffer = await decodeAudioData(decode(base64Audio), audioContextRef.current, 24000, 1);
        const source = audioContextRef.current.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContextRef.current.destination);
        source.start();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  return (
    <div className="pt-32 pb-24 px-6 bg-white min-h-screen flex flex-col items-center">
      {!isAnushthanStarted ? (
        <div className="max-w-2xl w-full bg-[#FFF8E7] rounded-[4rem] p-12 md:p-20 divine-shadow border border-[#D4AF37]/20 text-center animate-fade-in">
          <DIVINE_ICONS.Lotus className="w-20 h-20 mx-auto text-[#D4AF37] mb-8 animate-float" />
          <h1 className="text-4xl md:text-6xl font-devanagari font-bold text-[#7B1E1E] mb-6">
            {language === 'hi' ? ANUSHTHAN_INFO.title.hi : ANUSHTHAN_INFO.title.en}
          </h1>
          <p className="text-gray-500 italic mb-12">
            {language === 'hi' ? ANUSHTHAN_INFO.subtitle.hi : ANUSHTHAN_INFO.subtitle.en}
          </p>
          <div className="space-y-6 mb-12">
            <input 
              type="text" 
              placeholder={language === 'hi' ? 'आपका नाम' : 'Your Name'}
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              className="w-full px-8 py-5 rounded-full border-2 border-[#D4AF37]/20 focus:border-[#D4AF37] focus:ring-0 text-xl font-devanagari"
            />
            <input 
              type="text" 
              placeholder={language === 'hi' ? 'आपकी राशि' : 'Your Rashi'}
              value={rashi}
              onChange={(e) => setRashi(e.target.value)}
              className="w-full px-8 py-5 rounded-full border-2 border-[#D4AF37]/20 focus:border-[#D4AF37] focus:ring-0 text-xl font-devanagari"
            />
          </div>
          <button 
            onClick={startAnushthan}
            disabled={!userName.trim()}
            className="gold-gradient text-white px-16 py-6 rounded-full text-xl font-black shadow-2xl hover:scale-105 transition-all disabled:opacity-30"
          >
            {language === 'hi' ? 'संकल्प लें' : 'Take Sankalp'}
          </button>
        </div>
      ) : (
        <div className="w-full max-w-5xl text-center">
          <div className="relative h-[500px] flex items-center justify-center mb-12">
             {/* Virtual Shivaling Silhouette */}
             <div className="absolute inset-0 flex items-center justify-center opacity-10">
                <DIVINE_ICONS.Trishul className="w-[300px] h-[300px] text-[#7B1E1E] animate-breathe" />
             </div>
             
             <div className="relative z-10 w-64 h-80 bg-gradient-to-t from-[#1a1a1a] to-[#444] rounded-full shadow-[0_40px_100px_rgba(0,0,0,0.5)] border-t-4 border-white/10 flex flex-col items-center justify-center">
                <div className="text-5xl mb-4 animate-flicker">🔱</div>
                <div className="text-[#D4AF37] font-devanagari font-bold text-lg opacity-40">ॐ नमः शिवाय</div>
             </div>

             {/* Floating Flowers */}
             {[...Array(offeringCount)].map((_, i) => (
                <div 
                  key={i} 
                  className="absolute animate-float text-4xl pointer-events-none"
                  style={{ 
                    left: `${45 + (Math.random() * 10 - 5)}%`, 
                    top: `${30 + (Math.random() * 10 - 5)}%`,
                    animationDuration: `${2 + Math.random()}s`
                  }}
                >
                  🌸
                </div>
             ))}
          </div>

          <div className="space-y-10">
            <p className="text-3xl font-devanagari font-bold text-[#7B1E1E]">
              {language === 'hi' ? `आशीर्वाद प्राप्तकर्ता: ${userName}` : `Blessing Recipient: ${userName}`}
            </p>
            
            <div className="flex justify-center space-x-8">
               <button 
                onClick={() => setOfferingCount(prev => prev + 1)}
                className="bg-[#FFF1B8] border-2 border-[#D4AF37]/40 w-24 h-24 rounded-full flex items-center justify-center text-4xl shadow-lg hover:scale-110 active:scale-90 transition-all"
               >
                 🌸
               </button>
               <button 
                onClick={receiveBlessing}
                disabled={isGeneratingAudio}
                className="gold-gradient text-white px-12 py-6 rounded-full font-black shadow-2xl flex items-center space-x-4 disabled:opacity-50"
               >
                 {isGeneratingAudio ? (
                   <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                 ) : (
                   <span className="text-2xl">🔊</span>
                 )}
                 <span>{language === 'hi' ? 'दिव्य आशीर्वाद सुनें' : 'Listen Divine Blessing'}</span>
               </button>
            </div>

            <p className="text-gray-400 italic font-medium">
              {language === 'hi' ? 'पुष्प अर्पित करें और पंडित जी का आशीर्वाद सुनें' : 'Offer flowers and listen to Pandit Ji\'s blessing'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default VirtualAnushthanPage;
