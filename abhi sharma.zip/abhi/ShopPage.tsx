
import React from 'react';
import { Language } from '../types';
import { PRODUCTS_DATA, DIVINE_ICONS } from '../constants';

const ShopPage: React.FC<{ language: Language; onBook: (item: string) => void }> = ({ language, onBook }) => {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20 animate-reveal">
          <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">वैदिक स्टोर</span>
          <h1 className="text-4xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6 shlok-mask">
            {language === 'hi' ? 'सिद्ध आध्यात्मिक सामग्री' : 'Authentic Spiritual Items'}
          </h1>
          <p className="text-gray-500 italic max-w-2xl mx-auto font-devanagari">
            {language === 'hi' 
              ? 'हमारे सभी उत्पाद उज्जैन के विद्वान पंडितों द्वारा अभिमंत्रित और सिद्ध किए गए हैं।' 
              : 'All our products are energized and blessed by expert scholars of Ujjain.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {PRODUCTS_DATA.map((product) => (
            <div key={product.id} className="bg-white rounded-[3rem] p-8 shadow-xl border border-gray-100 hover:shadow-[#D4AF37]/20 transition-all group">
              <div className="aspect-square rounded-[2rem] overflow-hidden mb-8 relative">
                <img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute top-4 right-4 bg-white/90 px-3 py-1 rounded-full text-[10px] font-black text-[#D4AF37] uppercase tracking-widest">In Stock</div>
              </div>
              <h3 className="text-xl font-devanagari font-bold text-[#7B1E1E] mb-2">
                {language === 'hi' ? product.name.hi : product.name.en}
              </h3>
              <p className="text-2xl font-black text-[#D4AF37] mb-6">₹{product.price}</p>
              <button 
                onClick={() => onBook(language === 'hi' ? product.name.hi : product.name.en)}
                className="gold-gradient text-white w-full py-4 rounded-full font-bold shadow-lg hover:shadow-xl active:scale-95 transition-all"
              >
                {language === 'hi' ? 'अभी खरीदें' : 'Buy Now'}
              </button>
            </div>
          ))}
        </div>

        <div className="mt-24 p-12 rounded-[4rem] bg-[#7B1E1E] text-white flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center space-x-6">
            <DIVINE_ICONS.Om className="w-16 h-16 text-[#D4AF37]" />
            <div>
              <h3 className="text-2xl font-devanagari font-bold">{language === 'hi' ? 'विशेष आवश्यकता?' : 'Special Requirement?'}</h3>
              <p className="opacity-70 font-devanagari">{language === 'hi' ? 'अपनी कुंडली के अनुसार यंत्र या रत्न सिद्ध करवाएं।' : 'Get energized Yantra or Gemstones as per your birth chart.'}</p>
            </div>
          </div>
          <button 
            onClick={() => onBook('Special Custom Request')}
            className="bg-white text-[#7B1E1E] px-10 py-4 rounded-full font-black text-sm uppercase tracking-widest"
          >
            Contact Pandit Ji
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShopPage;
