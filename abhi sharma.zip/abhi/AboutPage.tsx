import React from 'react';
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

const AboutPage: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-white min-h-screen">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-20 animate-reveal">
          <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">हमारा परिचय</span>
          <h1 className="text-4xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6 shlok-mask">
            {language === 'hi' ? 'ज्योतिष अनुष्ठान केंद्र' : 'Vedic Ritual Center'}
          </h1>
          <div className="flex items-center justify-center space-x-4 opacity-30">
            <div className="h-px w-16 bg-[#7B1E1E]"></div>
            <DIVINE_ICONS.Trishul className="w-8 h-8 text-[#D4AF37]" />
            <div className="h-px w-16 bg-[#7B1E1E]"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-24">
          <div className="space-y-8">
            <h2 className="text-3xl md:text-5xl font-devanagari font-bold text-[#7B1E1E]">हमारी गौरवशाली परंपरा</h2>
            <p className="text-gray-600 text-lg md:text-xl font-devanagari leading-relaxed">
              {language === 'hi' 
                ? 'उज्जैन (अवंतिका) नगरी की पावन धरा पर हमारा केंद्र दशकों से शुद्ध वैदिक पद्धतियों द्वारा भक्तों की सेवा कर रहा है। हमारे सभी पंडित जी शास्त्रों के प्रकांड विद्वान हैं और महाकाल की कृपा से अनुष्ठान संपन्न कराते हैं।'
                : 'Based in the holy land of Ujjain, our center has been serving devotees for decades through authentic Vedic methods. Our scholars are masters of scriptures and perform rituals with the grace of Lord Mahakal.'}
            </p>
            <div className="p-8 bg-[#FFF8E7] rounded-[2.5rem] border-l-4 border-[#D4AF37]">
              <p className="text-[#7B1E1E] font-devanagari font-bold italic text-xl">
                “धर्मो रक्षति रक्षितः”
              </p>
              <p className="text-sm text-[#D4AF37] mt-2 font-bold uppercase tracking-widest">Ancient Vedic Motto</p>
            </div>
          </div>
          <div className="rounded-[4rem] overflow-hidden shadow-2xl h-[500px]">
            <img src="https://images.unsplash.com/photo-1590766940554-634a7ed41450?q=80&w=1200" className="w-full h-full object-cover" />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
          {[
            { title: { hi: "वैदिक शुद्धता", en: "Vedic Purity" }, icon: "🪔" },
            { title: { hi: "सटीक परामर्श", en: "Accurate Guidance" }, icon: "📜" },
            { title: { hi: "महाकाल आशीर्वाद", en: "Mahakal Blessings" }, icon: "🔱" }
          ].map((item, idx) => (
            <div key={idx} className="bg-white p-10 rounded-[3rem] text-center border border-gray-100 shadow-xl hover:scale-105 transition-all">
              <div className="text-5xl mb-6">{item.icon}</div>
              <h4 className="text-xl font-devanagari font-bold text-[#7B1E1E]">{language === 'hi' ? item.title.hi : item.title.en}</h4>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AboutPage;