
import React from 'react';
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

interface SidebarProps {
  language: Language;
  currentPath: string;
  onNavigate: (path: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ language, currentPath, onNavigate, isOpen, onClose }) => {
  const menuItems = [
    { path: 'home', icon: '🏠', hi: 'होम', en: 'Home' },
    { path: 'about', icon: 'ℹ️', hi: 'हमारे बारे में', en: 'About Us' },
    { path: 'services', icon: '🕉️', hi: 'सेवाएं', en: 'Services' },
    { path: 'kundali', icon: '🔮', hi: 'जन्म कुंडली', en: 'Janma Kundali' },
    { path: 'kumbh', icon: '🏺', hi: 'सिंहस्थ कुंभ', en: 'Kumbh Mela' },
    { path: 'shop', icon: '🛍️', hi: 'वैदिक स्टोर', en: 'Spiritual Shop' },
    { path: 'anushthan', icon: '🕯️', hi: 'आभासी अनुष्ठान', en: 'Virtual Anushthan' },
    { path: 'wizard', icon: '✨', hi: 'अनुष्ठान परामर्श (AI)', en: 'Ritual Wizard (AI)' },
    { path: 'dream', icon: '🌙', hi: 'स्वप्न विचार (AI)', en: 'Dream Interpreter' },
    { path: 'chat', icon: '🤖', hi: 'वैदिक AI पंडित', en: 'Vedic AI Pandit' },
    { path: 'rashifal', icon: '♋', hi: 'राशिफल', en: 'Rashifal' },
    { path: 'bhaktisagar', icon: '🪔', hi: 'भक्ति सागर', en: 'Bhakti Sagar' },
    { path: 'darshan', icon: '🏛️', hi: 'उज्जैन दर्शन', en: 'Ujjain Darshan' },
    { path: 'blog', icon: '📜', hi: 'ज्ञान गंगा', en: 'Vedic Blog' },
    { path: 'faq', icon: '❓', hi: 'सामान्य प्रश्न', en: 'FAQs' },
    { path: 'contact', icon: '📞', hi: 'संपर्क करें', en: 'Contact Us' },
  ];

  return (
    <>
      {isOpen && <div className="fixed inset-0 bg-black/60 backdrop-blur-xl z-40 md:hidden" onClick={onClose} />}
      <aside className={`fixed left-0 top-0 h-full w-72 bg-white border-r border-[#D4AF37]/20 z-50 transition-transform duration-700 ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 shadow-2xl`}>
        <div className="p-10 text-center border-b border-[#D4AF37]/10 relative overflow-hidden">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-3xl border-2 border-[#D4AF37]/30 flex items-center justify-center animate-flicker bg-[#FFF1B8]/20">
               <DIVINE_ICONS.Om className="w-8 h-8 text-[#D4AF37]" />
            </div>
          </div>
          <div className="text-[#7B1E1E] text-2xl font-devanagari font-bold leading-tight">
            उज्जैन वाले <br/> <span className="text-[#D4AF37]">पंडित जी</span>
          </div>
        </div>
        <nav className="mt-8 px-4 overflow-y-auto h-[calc(100vh-320px)] custom-scrollbar">
          {menuItems.map((item) => (
            <button
              key={item.path}
              onClick={() => { onNavigate(item.path); onClose(); }}
              className={`w-full flex items-center space-x-4 px-6 py-4 mb-2 rounded-3xl transition-all ${currentPath === item.path ? 'bg-[#FFF1B8]/30 border-l-4 border-[#D4AF37] text-[#7B1E1E]' : 'hover:bg-[#FFF8E7] text-[#7B1E1E]/60 border-l-4 border-transparent'}`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className={`text-sm font-bold tracking-wide ${language === 'hi' ? 'font-devanagari text-lg' : ''}`}>
                {language === 'hi' ? item.hi : item.en}
              </span>
            </button>
          ))}
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;
