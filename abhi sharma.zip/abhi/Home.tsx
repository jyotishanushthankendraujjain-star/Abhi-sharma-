
import React from 'react';
import Hero from '../components/Hero';
import PanchangWidget from '../components/PanchangWidget';
import { Language } from '../types';
import { SERVICES_DATA, DEITY_GALLERY, PRODUCTS_DATA, DIVINE_ICONS, TESTIMONIALS_DATA, FESTIVALS_DATA } from '../constants';

interface HomeProps {
  language: Language;
  onNavigate: (p: string) => void;
  onBook: (service?: string) => void;
}

const Home: React.FC<HomeProps> = ({ language, onNavigate, onBook }) => {
  return (
    <div className="pb-20">
      {/* Live Festival Ticker */}
      <div className="bg-[#7B1E1E] text-white py-2 overflow-hidden sticky top-[68px] z-40 shadow-md">
        <div className="flex animate-mantra-scroll whitespace-nowrap gap-12 text-xs md:text-sm font-bold tracking-widest uppercase">
           {FESTIVALS_DATA.map((fest, i) => (
             <span key={i} className="flex items-center">
               <span className="text-[#D4AF37] mr-2">✦</span> 
               {language === 'hi' ? fest.name.hi : fest.name.en} : {fest.date}
             </span>
           ))}
           {/* Duplicate for smooth loop */}
           {FESTIVALS_DATA.map((fest, i) => (
             <span key={`dup-${i}`} className="flex items-center">
               <span className="text-[#D4AF37] mr-2">✦</span> 
               {language === 'hi' ? fest.name.hi : fest.name.en} : {fest.date}
             </span>
           ))}
        </div>
      </div>

      <Hero language={language} />

      {/* Quick Action Tools */}
      <section className="px-6 -mt-10 relative z-40 mb-16">
         <div className="max-w-6xl mx-auto">
            <div className="bg-white rounded-[2.5rem] p-8 shadow-2xl border border-[#D4AF37]/20 flex flex-wrap justify-center gap-6 md:gap-12 text-center">
               {[
                 { id: 'kundali', icon: '🔮', label: { hi: 'कुंडली निर्माण', en: 'Kundli' } },
                 { id: 'rashifal', icon: '♈', label: { hi: 'दैनिक राशिफल', en: 'Horoscope' } },
                 { id: 'services', icon: '🔥', label: { hi: 'विवाह मिलान', en: 'Match Making' } },
                 { id: 'wizard', icon: '✨', label: { hi: 'परामर्श (AI)', en: 'Ask AI' } },
               ].map((tool) => (
                 <button 
                   key={tool.id} 
                   onClick={() => onNavigate(tool.id)}
                   className="group flex flex-col items-center w-24 md:w-32"
                 >
                   <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-[#FFF8E7] border-2 border-[#D4AF37]/20 flex items-center justify-center text-3xl md:text-4xl shadow-md group-hover:scale-110 group-hover:border-[#D4AF37] transition-all duration-300">
                      {tool.icon}
                   </div>
                   <span className="mt-3 text-sm font-bold text-[#7B1E1E] font-devanagari group-hover:text-[#D4AF37] transition-colors">
                     {language === 'hi' ? tool.label.hi : tool.label.en}
                   </span>
                 </button>
               ))}
            </div>
         </div>
      </section>
      
      {/* Services Grid Overlay & Panchang */}
      <section className="px-6 relative z-30">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-8">
          <div className="hidden lg:block w-80 shrink-0 sticky top-32 h-fit">
             <PanchangWidget language={language} />
             
             {/* Daily Thought */}
             <div className="mt-6 bg-[#7B1E1E] text-white p-6 rounded-[2rem] text-center shadow-xl">
               <DIVINE_ICONS.Om className="w-8 h-8 text-[#D4AF37] mx-auto mb-4" />
               <p className="font-devanagari italic text-sm opacity-90">
                 "सत्यमेव जयते नानृतं सत्येन पन्था विततो देवयानः"
               </p>
             </div>
          </div>

          <div className="flex-1">
            <div className="flex items-center justify-between mb-8">
               <h2 className="text-3xl font-devanagari font-bold text-[#7B1E1E]">
                  {language === 'hi' ? 'प्रमुख सेवाएं' : 'Featured Services'}
               </h2>
               <button onClick={() => onNavigate('services')} className="text-[#D4AF37] font-bold text-sm uppercase tracking-wider hover:underline">
                  {language === 'hi' ? 'सभी देखें' : 'View All'} →
               </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {SERVICES_DATA.slice(0, 4).map((cat) => (
                <div 
                  key={cat.id} 
                  className="bg-white p-8 rounded-[2.5rem] shadow-lg border border-gray-100 hover:border-[#D4AF37]/50 hover:shadow-2xl transition-all group overflow-hidden relative cursor-pointer"
                  onClick={() => onNavigate('services')}
                >
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                     {cat.id === 'jyotish' ? <DIVINE_ICONS.Om className="w-32 h-32" /> : <DIVINE_ICONS.Trishul className="w-32 h-32" />}
                  </div>

                  <div className="w-12 h-12 bg-[#FFF8E7] rounded-xl flex items-center justify-center text-2xl mb-4 shadow-inner">
                    {cat.id === 'jyotish' ? '🕉️' : '🔱'}
                  </div>
                  <h3 className="text-xl font-devanagari font-bold text-[#7B1E1E] mb-2 group-hover:text-[#D4AF37] transition-colors">
                    {language === 'hi' ? cat.name.hi : cat.name.en}
                  </h3>
                  <p className="text-sm text-gray-500 mb-6 font-devanagari line-clamp-2">
                     {cat.items.map(i => language === 'hi' ? i.title.hi : i.title.en).join(', ')}
                  </p>
                  <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest group-hover:translate-x-2 transition-transform inline-block">
                    Explore
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
        {/* Mobile Panchang */}
        <div className="lg:hidden mt-8 max-w-sm mx-auto">
           <PanchangWidget language={language} />
        </div>
      </section>

      {/* Live Darshan Placeholder */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto bg-black rounded-[3rem] overflow-hidden shadow-2xl relative group">
           <div className="absolute inset-0 opacity-40">
              <img src="https://images.unsplash.com/photo-1628104523091-81766627d353?q=80&w=1600" className="w-full h-full object-cover" />
           </div>
           <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent"></div>
           <div className="relative z-10 p-10 md:p-20 flex flex-col items-start justify-center h-full min-h-[400px]">
              <div className="flex items-center space-x-3 mb-6 bg-red-600/20 backdrop-blur-md px-4 py-1.5 rounded-full border border-red-500/50">
                 <div className="w-2 h-2 bg-red-600 rounded-full animate-pulse"></div>
                 <span className="text-white font-bold uppercase tracking-widest text-[10px]">Live from Ujjain</span>
              </div>
              <h2 className="text-4xl md:text-6xl text-white font-devanagari font-bold mb-4 leading-tight">
                 {language === 'hi' ? 'श्री महाकालेश्वर भस्म आरती' : 'Shree Mahakaleshwar Bhasm Aarti'}
              </h2>
              <p className="text-white/70 max-w-lg mb-8 text-lg font-devanagari">
                 {language === 'hi' ? 'सीधा प्रसारण देखें और बाबा महाकाल का आशीर्वाद प्राप्त करें।' : 'Watch live telecast and seek blessings from Baba Mahakal.'}
              </p>
              <button onClick={() => onNavigate('darshan')} className="bg-white text-black px-10 py-4 rounded-full font-black flex items-center space-x-3 hover:scale-105 transition-transform">
                 <span className="text-2xl">▶</span>
                 <span>{language === 'hi' ? 'दर्शन करें' : 'Watch Live'}</span>
              </button>
           </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-6 bg-[#FFF8E7]/30">
         <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
               <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">भक्तों के अनुभव</span>
               <h2 className="text-4xl md:text-5xl font-devanagari font-bold text-[#7B1E1E] mt-4 shlok-mask">श्रद्धा और विश्वास</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
               {TESTIMONIALS_DATA.map((t) => (
                  <div key={t.id} className="bg-white p-8 rounded-[2.5rem] shadow-lg border border-gray-100 relative">
                     <div className="text-[#D4AF37] text-6xl font-serif absolute top-4 left-6 opacity-20">"</div>
                     <p className="text-gray-600 font-devanagari italic mb-8 relative z-10 leading-relaxed">
                        {language === 'hi' ? t.text.hi : t.text.en}
                     </p>
                     <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-[#7B1E1E] rounded-full text-white flex items-center justify-center font-bold text-xl">
                           {t.name.charAt(0)}
                        </div>
                        <div>
                           <h4 className="font-bold text-[#7B1E1E]">{t.name}</h4>
                           <p className="text-xs text-gray-400 uppercase tracking-wider">{t.location}</p>
                        </div>
                     </div>
                     <div className="flex space-x-1 absolute bottom-8 right-8 text-[#D4AF37]">
                        {[...Array(t.rating)].map((_, i) => <span key={i}>★</span>)}
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </section>

      {/* Divine Presence Gallery */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-12">
            <div>
               <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">दिव्य दर्शन</span>
               <h2 className="text-4xl font-devanagari font-bold text-[#7B1E1E] mt-2">दैवीय स्वरूप</h2>
            </div>
            <button className="hidden md:block gold-gradient text-white px-8 py-3 rounded-full font-bold text-sm">
               View Gallery
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {DEITY_GALLERY.slice(0, 3).map((d) => (
              <div key={d.id} className="group relative h-80 rounded-[2.5rem] overflow-hidden shadow-2xl transition-all duration-700 hover:shadow-[#D4AF37]/30">
                <img src={d.image} alt={d.name.en} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                <div className="absolute bottom-8 left-8 text-white">
                  <p className="text-2xl font-devanagari font-bold">{language === 'hi' ? d.name.hi : d.name.en}</p>
                  <p className="text-[10px] uppercase tracking-[0.4em] text-[#D4AF37] mt-2 font-black">Sacred Presence</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Spiritual Shop Teaser */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto bg-[#7B1E1E] rounded-[3rem] p-12 md:p-20 relative overflow-hidden text-white flex flex-col md:flex-row items-center justify-between gap-12">
           <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,#A00000_0%,#7B1E1E_100%)]"></div>
           <div className="absolute right-0 top-0 opacity-10 pointer-events-none">
              <DIVINE_ICONS.Om className="w-96 h-96 text-[#D4AF37]" />
           </div>

           <div className="relative z-10 max-w-xl">
              <span className="text-[#D4AF37] font-black text-xs tracking-[0.4em] uppercase block mb-4">Vedic Store</span>
              <h2 className="text-4xl md:text-6xl font-devanagari font-bold mb-6">सिद्ध आध्यात्मिक सामग्री</h2>
              <p className="text-white/80 text-lg leading-relaxed font-devanagari">
                 {language === 'hi' 
                   ? 'रुद्राक्ष, यंत्र और रत्न - पूर्ण विधि विधान से प्राण प्रतिष्ठित।' 
                   : 'Rudraksha, Yantra, and Gemstones - Energized with complete rituals.'}
              </p>
           </div>

           <div className="relative z-10 flex flex-col sm:flex-row gap-6">
              <button onClick={() => onNavigate('shop')} className="bg-white text-[#7B1E1E] px-10 py-5 rounded-full font-black shadow-xl hover:scale-105 transition-transform">
                 {language === 'hi' ? 'दुकान देखें' : 'Visit Shop'}
              </button>
           </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
