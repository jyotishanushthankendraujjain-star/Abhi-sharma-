
import React, { useState } from 'react';
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

interface BookingModalProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  serviceName?: string;
}

const BookingModal: React.FC<BookingModalProps> = ({ language, isOpen, onClose, serviceName }) => {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  
  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = language === 'hi' 
      ? `नमस्ते पंडित जी, मैं ${name} हूँ। मैं ${serviceName || 'ज्योतिष परामर्श'} के लिए दिनांक ${date} को बुकिंग करना चाहता हूँ।`
      : `Namaste Pandit Ji, I am ${name}. I would like to book ${serviceName || 'Consultation'} for date ${date}.`;
    
    const url = `https://wa.me/919876543210?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-white rounded-[2.5rem] p-8 md:p-10 w-full max-w-lg relative z-10 divine-shadow animate-reveal border border-[#D4AF37]/20">
        <button onClick={onClose} className="absolute top-6 right-6 text-2xl opacity-50 hover:opacity-100">✕</button>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#FFF8E7] rounded-full flex items-center justify-center mx-auto mb-4 border border-[#D4AF37]/30">
             <DIVINE_ICONS.Om className="w-8 h-8 text-[#D4AF37]" />
          </div>
          <h3 className="text-2xl font-devanagari font-bold text-[#7B1E1E]">
            {language === 'hi' ? 'बुकिंग विवरण' : 'Booking Details'}
          </h3>
          <p className="text-sm text-[#D4AF37] font-bold uppercase tracking-widest mt-2">
            {serviceName || (language === 'hi' ? 'सामान्य परामर्श' : 'General Consultation')}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-500 mb-2 ml-2">
              {language === 'hi' ? 'आपका नाम' : 'Your Name'}
            </label>
            <input 
              type="text" 
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-6 py-4 rounded-xl border-2 border-gray-100 focus:border-[#D4AF37] focus:outline-none font-medium"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-500 mb-2 ml-2">
              {language === 'hi' ? 'पसंदीदा तारीख' : 'Preferred Date'}
            </label>
            <input 
              type="date" 
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-6 py-4 rounded-xl border-2 border-gray-100 focus:border-[#D4AF37] focus:outline-none font-medium"
            />
          </div>
          
          <button type="submit" className="w-full gold-gradient text-white py-5 rounded-xl font-bold text-lg shadow-xl hover:scale-[1.02] transition-transform">
            {language === 'hi' ? 'व्हाट्सएप पर बुक करें' : 'Book via WhatsApp'}
          </button>
        </form>
        
        <p className="text-center text-xs text-gray-400 mt-6 italic">
          {language === 'hi' ? 'आपको सीधे पंडित जी के व्हाट्सएप पर ले जाया जाएगा।' : 'You will be redirected to Pandit Ji\'s WhatsApp.'}
        </p>
      </div>
    </div>
  );
};

export default BookingModal;
