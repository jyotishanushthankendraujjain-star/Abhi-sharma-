import React from 'react';
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

const Hero: React.FC<{ language: Language }> = ({ language }) => {
  const mantraText = "ॐ नमः शिवाय ॐ नमः शिवाय ॐ नमः शिवाय ॐ नमः शिवाय ॐ नमः शिवाय ॐ नमः शिवाय ॐ नमः शिवाय ";

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-white pt-24 md:pt-32">
      {/* Background Lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,#FFF1B8_0%,#FFFFFF_80%)] opacity-70 z-0"></div>
      
      {/* Scrolling Shimmering Mantras (Deep Background) */}
      <div className="absolute top-[30%] left-0 w-full overflow-hidden pointer-events-none select-none z-10">
        <div className="flex animate-mantra-scroll whitespace-nowrap">
          <div className="text-[14vw] font-devanagari font-black text-[#7B1E1E] px-8 animate-divine-shimmer">
            {mantraText}
          </div>
          <div className="text-[14vw] font-devanagari font-black text-[#7B1E1E] px-8 animate-divine-shimmer">
            {mantraText}
          </div>
        </div>
      </div>

      {/* Silhouette Layer (Middle) */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none z-20">
        <DIVINE_ICONS.Trishul className="w-[85vw] md:w-[55vw] h-auto text-[#7B1E1E] opacity-[0.04] animate-pulse" />
      </div>

      {/* Main Content (Top Layer) */}
      <div className="relative z-30 text-center max-w-6xl px-6 animate-reveal">
        <div className="inline-flex items-center space-x-3 mb-8 px-6 py-2 rounded-full border border-[#D4AF37]/30 bg-white/40 backdrop-blur-md">
          <DIVINE_ICONS.Om className="w-5 h-5 text-[#D4AF37]" />
          <span className="text-[#7B1E1E] text-[10px] md:text-xs font-black tracking-[0.4em] uppercase font-devanagari">
            {language === 'hi' ? 'अवंतिका नगरी • उज्जैन धाम' : 'Holy City of Ujjain'}
          </span>
        </div>
        
        <h1 className="text-5xl md:text-8xl lg:text-[10rem] font-devanagari font-bold text-[#7B1E1E] mb-8 leading-[1.1] tracking-tight">
          {language === 'hi' ? (
            <span className="block">ज्योतिष अनुष्ठान <br/> <span className="shlok-mask font-black">कर्मकांड केंद्र</span></span>
          ) : (
            <span className="block">Divine Vedic <br/> <span className="shlok-mask font-playfair italic">Sanctuary</span></span>
          )}
        </h1>

        <div className="mb-10 flex items-center justify-center space-x-6 opacity-30">
           <div className="h-px w-20 bg-[#D4AF37]"></div>
           <span className="text-3xl text-[#D4AF37]">🔱</span>
           <div className="h-px w-20 bg-[#D4AF37]"></div>
        </div>

        <p className="text-lg md:text-3xl text-[#7B1E1E]/80 mb-12 font-devanagari italic max-w-4xl mx-auto leading-relaxed px-4">
          {language === 'hi' 
            ? '“आकाशे तारकं लिंगं पाताले हाटकेश्वरम्। मृत्युलोके महाकालं त्रिलिंगं प्रनम्यतः॥”'
            : '"I bow to the three Lingas: the Starry Linga, Hatakeshwara, and Mahakal."'}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <button className="gold-gradient text-white px-10 py-5 rounded-full text-lg font-black shadow-xl hover:scale-105 transition-all flex items-center group active:scale-95">
            {language === 'hi' ? 'पूजन बुक करें' : 'Book Ritual'}
            <span className="ml-3 text-2xl group-hover:rotate-12 transition-transform">🕉️</span>
          </button>
          <button className="bg-white/60 backdrop-blur-md border border-[#7B1E1E]/20 text-[#7B1E1E] px-10 py-5 rounded-full text-lg font-black hover:bg-white hover:text-[#D4AF37] transition-all active:scale-95">
            {language === 'hi' ? 'परामर्श लें' : 'Consultation'}
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;