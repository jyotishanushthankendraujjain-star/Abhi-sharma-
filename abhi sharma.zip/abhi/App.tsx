
import React, { useState, useEffect } from 'react';
import { Language } from './types';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import FloatingActions from './components/FloatingActions';
import BookingModal from './components/BookingModal';
import Home from './pages/Home';
import ServicesPage from './pages/ServicesPage';
import ShopPage from './pages/ShopPage';
import BlogPage from './pages/BlogPage';
import KundaliPage from './pages/KundaliPage';
import RashifalPage from './pages/RashifalPage';
import BhaktiSagarPage from './pages/BhaktiSagarPage';
import VedicAIPage from './pages/VedicAIPage';
import DarshanPage from './pages/DarshanPage';
import KumbhMelaPage from './pages/KumbhMelaPage';
import RitualWizardPage from './pages/RitualWizardPage';
import DreamInterpreterPage from './pages/DreamInterpreterPage';
import VirtualAnushthanPage from './pages/VirtualAnushthanPage';
import FAQPage from './pages/FAQPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import { DIVINE_ICONS } from './constants';

const App: React.FC = () => {
  const [language, setLanguage] = useState<Language>('hi');
  const [currentPath, setCurrentPath] = useState<string>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<string>('');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPath]);

  const handleBook = (serviceName?: string) => {
    setSelectedService(serviceName || '');
    setBookingModalOpen(true);
  };

  const renderPage = () => {
    switch (currentPath) {
      case 'home':
        return <Home language={language} onNavigate={setCurrentPath} onBook={handleBook} />;
      case 'services':
        return <ServicesPage language={language} onBook={handleBook} />;
      case 'kundali':
        return <KundaliPage language={language} />;
      case 'shop':
        return <ShopPage language={language} onBook={handleBook} />;
      case 'blog':
        return <BlogPage language={language} />;
      case 'rashifal':
        return <RashifalPage language={language} />;
      case 'bhaktisagar':
        return <BhaktiSagarPage language={language} />;
      case 'chat':
        return <VedicAIPage language={language} />;
      case 'darshan':
        return <DarshanPage language={language} />;
      case 'kumbh':
        return <KumbhMelaPage language={language} />;
      case 'wizard':
        return <RitualWizardPage language={language} />;
      case 'dream':
        return <DreamInterpreterPage language={language} />;
      case 'anushthan':
        return <VirtualAnushthanPage language={language} />;
      case 'faq':
        return <FAQPage language={language} />;
      case 'about':
        return <AboutPage language={language} />;
      case 'contact':
        return <ContactPage language={language} />;
      default:
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh] p-20 text-center animate-fade-in">
            <div className="w-24 h-24 bg-[#FFF1B8] rounded-full flex items-center justify-center text-4xl mb-8 border-2 border-[#D4AF37]/20 animate-float">
              🔱
            </div>
            <h2 className="text-4xl font-devanagari font-bold text-[#7B1E1E] mb-4">
              {language === 'hi' ? 'पृष्ठ निर्माणाधीन है' : 'Page Construction'}
            </h2>
            <button onClick={() => setCurrentPath('home')} className="gold-gradient text-white px-10 py-3 rounded-full font-bold">
              Return Home
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white selection:bg-[#D4AF37] selection:text-white">
      <Sidebar 
        language={language} 
        currentPath={currentPath} 
        onNavigate={setCurrentPath} 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      
      <div className="md:ml-72 flex flex-col min-h-screen relative">
        <Navbar 
          language={language} 
          onLanguageToggle={() => setLanguage(prev => prev === 'hi' ? 'en' : 'hi')} 
          onMenuToggle={() => setIsSidebarOpen(true)}
          onBook={() => handleBook()}
        />
        
        <main className="flex-1">
          {renderPage()}
        </main>

        <footer className="bg-[#1a1a1a] text-white py-24 px-6 md:px-12 relative overflow-hidden">
          <div className="absolute bottom-0 right-0 opacity-[0.03] translate-y-1/2 translate-x-1/2">
            <DIVINE_ICONS.Om className="w-[600px] h-[600px] text-white" />
          </div>
          
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16 relative z-10">
            <div className="col-span-1 md:col-span-2">
              <h4 className="text-4xl font-devanagari font-bold mb-8 text-[#D4AF37]">उज्जैन वाले पंडित जी</h4>
              <p className="text-lg opacity-60 italic font-medium">
                {language === 'hi' 
                  ? 'शुद्ध वैदिक परंपरा और उज्जैन की दिव्यता का संगम। हम आपको महाकाल के आशीर्वाद से जोड़ते हैं।' 
                  : 'A confluence of pure Vedic tradition and Ujjain\'s divinity. We connect you with Mahakal\'s blessings.'}
              </p>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase tracking-[0.4em] mb-8 text-[#D4AF37]">{language === 'hi' ? 'त्वरित लिंक' : 'Quick Links'}</h4>
              <ul className="space-y-4 text-sm opacity-50 font-bold">
                <li className="cursor-pointer hover:text-[#D4AF37]" onClick={() => setCurrentPath('home')}>Home</li>
                <li className="cursor-pointer hover:text-[#D4AF37]" onClick={() => setCurrentPath('services')}>Services</li>
                <li className="cursor-pointer hover:text-[#D4AF37]" onClick={() => setCurrentPath('shop')}>Spiritual Shop</li>
                <li className="cursor-pointer hover:text-[#D4AF37]" onClick={() => setCurrentPath('blog')}>Vedic Blog</li>
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase tracking-[0.4em] mb-8 text-[#D4AF37]">{language === 'hi' ? 'संपर्क' : 'Contact'}</h4>
              <ul className="space-y-4 text-sm opacity-50 font-bold">
                <li>Ram Ghat, Ujjain, MP</li>
                <li>+91 98765 43210</li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto mt-24 pt-10 border-t border-white/10 text-center">
            <p className="text-[10px] tracking-[0.3em] opacity-30 uppercase font-black">
              © 2024 Jyotish Anushthan Karmakand Kendra, Ujjain
            </p>
          </div>
        </footer>
      </div>

      <FloatingActions />
      <BookingModal 
        language={language} 
        isOpen={bookingModalOpen} 
        onClose={() => setBookingModalOpen(false)} 
        serviceName={selectedService} 
      />
    </div>
  );
};

export default App;
