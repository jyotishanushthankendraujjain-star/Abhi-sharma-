
import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

type TabType = 'chart' | 'planets' | 'ashtakvarga' | 'dasha' | 'dosha' | 'remedies' | 'prediction';
type ChartType = 'D1' | 'D9' | 'Chandra';

// --- Detailed Interface for API Response ---
interface KundaliData {
  meta: {
    name: string;
    dob: string;
    tob: string;
    place: string;
  };
  avakahada: {
    varna: string;
    vashya: string;
    yoni: string;
    gana: string;
    nadi: string;
    lagna: string;
    lagna_rashi_no: number; // 1-12
    nakshatra: string;
    charan: number;
    tithi: string;
    yog: string;
    karan: string;
    paya: string;
  };
  charts: {
    D1: { lagna_rashi: number; planets: Record<string, number> }; // Planet Name -> House No (1-12)
    D9: { lagna_rashi: number; planets: Record<string, number> };
    Chandra: { lagna_rashi: number; planets: Record<string, number> };
  };
  planets: Array<{
    name: string;
    rashi: string;
    degree: string;
    nakshatra: string;
    pada: number;
    house: number; 
    isRetro: boolean;
    isCombust: boolean;
    speed: string;
    dignity: string; 
  }>;
  ashtakvarga: Record<number, number>; // House No -> Points
  doshas: {
    mangal: { present: boolean; description: string };
    kaal_sarp: { present: boolean; type: string; description: string };
    pitra: { present: boolean; description: string };
    sade_sati: { status: boolean; phase: string; description: string };
  };
  yogas: Array<{ name: string; description: string }>;
  dasha: {
    current_mahadasha: string;
    current_antardasha: string;
    end_date: string;
  };
  remedies: {
    gemstone: string;
    rudraksha: string;
    mantra: string;
    donation: string;
  };
  prediction: {
    personality: string;
    career: string;
    finance: string;
    health: string;
    marriage: string;
  };
}

const KundaliPage: React.FC<{ language: Language }> = ({ language }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('chart');
  const [activeChart, setActiveChart] = useState<ChartType>('D1');
  const [data, setData] = useState<KundaliData | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    tob: '',
    place: ''
  });

  const generateKundali = async () => {
    if (!formData.name || !formData.dob || !formData.tob || !formData.place) return;
    
    setLoading(true);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
      
      // Professional Prompt Engineering for Accurate JSON
      const prompt = `
        Act as a professional Vedic Astrology Software Engine. 
        Calculate the complete Kundli for: Name: ${formData.name}, Date: ${formData.dob}, Time: ${formData.tob}, Place: ${formData.place}.
        
        CRITICAL: Return ONLY valid JSON. All text values must be in HINDI (Devanagari).
        
        Required Calculations:
        1. Calculate Lagna Rashi Number (1=Mesha...12=Meena) for D1, D9, and Chandra charts.
        2. Calculate House Number (1-12) for Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, Ketu for all 3 charts.
        3. Accurate degrees, nakshatras, and dignities (Exalted/Debilitated/Own).
        4. Sarvashtakavarga points (approximate based on planetary positions).
        5. Check Mangal, Kaal Sarp, Pitra Dosh, and Sade Sati.
        6. Identify 2-3 key Yogas (e.g., Gajakesari, Budhaditya).

        JSON Structure:
        {
          "meta": { "name": "${formData.name}", "dob": "${formData.dob}", "tob": "${formData.tob}", "place": "${formData.place}" },
          "avakahada": { 
             "varna": "String", "vashya": "String", "yoni": "String", "gana": "String", "nadi": "String", 
             "lagna": "String", "lagna_rashi_no": Int, "nakshatra": "String", "charan": Int, 
             "tithi": "String", "yog": "String", "karan": "String", "paya": "String"
          },
          "charts": {
            "D1": { "lagna_rashi": Int, "planets": { "Su": Int, "Mo": Int, "Ma": Int, "Me": Int, "Ju": Int, "Ve": Int, "Sa": Int, "Ra": Int, "Ke": Int } },
            "D9": { "lagna_rashi": Int, "planets": { "Su": Int, "Mo": Int, "Ma": Int, "Me": Int, "Ju": Int, "Ve": Int, "Sa": Int, "Ra": Int, "Ke": Int } },
            "Chandra": { "lagna_rashi": Int, "planets": { "Su": Int, "Mo": Int, "Ma": Int, "Me": Int, "Ju": Int, "Ve": Int, "Sa": Int, "Ra": Int, "Ke": Int } }
          },
          "planets": [
            { "name": "String", "rashi": "String", "degree": "DD°MM", "nakshatra": "String", "pada": Int, "house": Int, "isRetro": Bool, "isCombust": Bool, "speed": "String", "dignity": "String" }
          ],
          "ashtakvarga": { "1": Int, "2": Int, "3": Int, "4": Int, "5": Int, "6": Int, "7": Int, "8": Int, "9": Int, "10": Int, "11": Int, "12": Int },
          "doshas": {
            "mangal": { "present": Bool, "description": "String" },
            "kaal_sarp": { "present": Bool, "type": "String", "description": "String" },
            "pitra": { "present": Bool, "description": "String" },
            "sade_sati": { "status": Bool, "phase": "String", "description": "String" }
          },
          "yogas": [ { "name": "String", "description": "String" } ],
          "dasha": { "current_mahadasha": "Planet", "current_antardasha": "Planet", "end_date": "Year" },
          "remedies": { "gemstone": "String", "rudraksha": "String", "mantra": "String", "donation": "String" },
          "prediction": { "personality": "Text", "career": "Text", "finance": "Text", "health": "Text", "marriage": "Text" }
        }
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { 
          responseMimeType: 'application/json',
          thinkingConfig: { thinkingBudget: 1024 } // Small budget for faster calculation
        }
      });

      const jsonText = response.text || "{}";
      const parsedData = JSON.parse(jsonText);
      setData(parsedData);
      setStep(2);

    } catch (error) {
      console.error("Kundli Generation Error:", error);
      alert("तकनीकी त्रुटि। कृपया पुनः प्रयास करें।");
    } finally {
      setLoading(false);
    }
  };

  // --- Dynamic North Indian Chart Component ---
  const DynamicChart = ({ chartType, chartData }: { chartType: ChartType, chartData: any }) => {
    // North Indian Chart Coordinates (Percentage based on 100x100 viewBox)
    const houseCenters = {
      1: { x: 50, y: 25 }, 2: { x: 25, y: 12 }, 3: { x: 12, y: 25 }, 4: { x: 25, y: 50 },
      5: { x: 12, y: 75 }, 6: { x: 25, y: 88 }, 7: { x: 50, y: 75 }, 8: { x: 75, y: 88 },
      9: { x: 88, y: 75 }, 10: { x: 75, y: 50 }, 11: { x: 88, y: 25 }, 12: { x: 75, y: 12 }
    };

    const rashiPositions = {
      1: { x: 50, y: 45 }, 2: { x: 25, y: 25 }, 3: { x: 15, y: 35 }, 4: { x: 35, y: 50 },
      5: { x: 15, y: 65 }, 6: { x: 25, y: 75 }, 7: { x: 50, y: 55 }, 8: { x: 75, y: 75 },
      9: { x: 85, y: 65 }, 10: { x: 65, y: 50 }, 11: { x: 85, y: 35 }, 12: { x: 75, y: 25 }
    };

    const lagnaRashi = chartData[chartType]?.lagna_rashi || 1;
    const planets = chartData[chartType]?.planets || {};

    // Calculate Rashi Number for each house
    const getRashiForHouse = (houseNum: number) => {
      let rashi = (lagnaRashi + houseNum - 1) % 12;
      return rashi === 0 ? 12 : rashi;
    };

    // Group Planets by House
    const planetsInHouse: Record<number, string[]> = {};
    Object.entries(planets).forEach(([planet, house]) => {
      const h = house as number;
      if (!planetsInHouse[h]) planetsInHouse[h] = [];
      planetsInHouse[h].push(planet);
    });

    return (
      <svg viewBox="0 0 100 100" className="w-full h-full stroke-[#7B1E1E] stroke-[0.4] fill-none font-devanagari select-none">
         <defs>
           <filter id="paper" x="0%" y="0%" width="100%" height="100%">
             <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="5" result="noise" />
             <feDiffuseLighting in="noise" lightingColor="#FFF8E7" surfaceScale="2">
               <feDistantLight azimuth="45" elevation="60" />
             </feDiffuseLighting>
           </filter>
         </defs>
         
         <rect x="0" y="0" width="100" height="100" className="stroke-[0.8] stroke-[#D4AF37] fill-[#FFF8E7]/20" />
         
         {/* Main Diagonals */}
         <line x1="0" y1="0" x2="100" y2="100" />
         <line x1="100" y1="0" x2="0" y2="100" />
         {/* Diamond Lines */}
         <line x1="50" y1="0" x2="0" y2="50" />
         <line x1="0" y1="50" x2="50" y2="100" />
         <line x1="50" y1="100" x2="100" y2="50" />
         <line x1="100" y1="50" x2="50" y2="0" />

         {/* Lagna Indicator */}
         <text x="50" y="15" fontSize="2.5" className="fill-[#7B1E1E] font-bold opacity-60" textAnchor="middle">लग्न</text>

         {/* Houses Loop */}
         {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(house => (
           <React.Fragment key={house}>
             {/* Rashi Number */}
             <text 
               x={rashiPositions[house as keyof typeof rashiPositions].x} 
               y={rashiPositions[house as keyof typeof rashiPositions].y} 
               fontSize="2.5" 
               className="fill-[#D4AF37] font-bold opacity-80" 
               textAnchor="middle"
             >
               {getRashiForHouse(house)}
             </text>

             {/* Planets */}
             {planetsInHouse[house] && (
               <text 
                 x={houseCenters[house as keyof typeof houseCenters].x} 
                 y={houseCenters[house as keyof typeof houseCenters].y} 
                 fontSize="3" 
                 className="fill-[#7B1E1E] font-bold" 
                 textAnchor="middle"
               >
                 {planetsInHouse[house].map((p, i) => (
                   <tspan key={i} x={houseCenters[house as keyof typeof houseCenters].x} dy={i === 0 ? 0 : 3.5}>
                     {p}
                   </tspan>
                 ))}
               </text>
             )}
           </React.Fragment>
         ))}
      </svg>
    );
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-[#FFF8E7] min-h-screen flex items-center justify-center">
      <div className="max-w-[95rem] w-full bg-white rounded-[3rem] divine-shadow border border-[#D4AF37]/20 relative overflow-hidden min-h-[850px]">
        {/* Background Watermarks */}
        <div className="absolute top-[-100px] left-[-100px] opacity-5 pointer-events-none">
           <DIVINE_ICONS.Om className="w-[500px] h-[500px] text-[#7B1E1E]" />
        </div>

        {step === 1 && (
          <div className="h-full flex flex-col items-center justify-center p-8 md:p-16 animate-fade-in relative z-10">
            {loading ? (
              <div className="text-center">
                <div className="relative w-32 h-32 mx-auto mb-8">
                  <div className="absolute inset-0 border-4 border-[#D4AF37]/30 rounded-full animate-ping"></div>
                  <div className="absolute inset-0 border-4 border-t-[#7B1E1E] rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center text-3xl">🕉️</div>
                </div>
                <h3 className="text-3xl font-devanagari font-bold text-[#7B1E1E] animate-pulse">
                  ग्रह स्थिति की सूक्ष्म गणना हो रही है...
                </h3>
                <p className="text-[#D4AF37] mt-4 font-bold tracking-[0.2em] uppercase text-sm">Panchang • Shodashvarga • Ashtakvarga</p>
              </div>
            ) : (
              <div className="w-full max-w-3xl text-center">
                <span className="text-[#D4AF37] font-black text-xs tracking-[0.4em] uppercase mb-4 block">Professional Vedic Software</span>
                <h1 className="text-5xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mb-6 leading-tight">
                  बृहत् कुंडली निर्माण
                </h1>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mb-12 bg-[#FFF8E7]/30 p-8 rounded-[2rem] border border-[#D4AF37]/10">
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-[#7B1E1E] uppercase tracking-wider ml-4">नाम (Name)</label>
                    <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full px-8 py-4 rounded-xl border border-[#D4AF37]/20 focus:border-[#D4AF37] focus:ring-0 bg-white text-lg font-devanagari shadow-sm" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-[#7B1E1E] uppercase tracking-wider ml-4">जन्म स्थान (Place)</label>
                    <input type="text" value={formData.place} onChange={(e) => setFormData({...formData, place: e.target.value})} className="w-full px-8 py-4 rounded-xl border border-[#D4AF37]/20 focus:border-[#D4AF37] focus:ring-0 bg-white text-lg font-devanagari shadow-sm" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-[#7B1E1E] uppercase tracking-wider ml-4">जन्म तिथि (Date)</label>
                    <input type="date" value={formData.dob} onChange={(e) => setFormData({...formData, dob: e.target.value})} className="w-full px-8 py-4 rounded-xl border border-[#D4AF37]/20 focus:border-[#D4AF37] focus:ring-0 bg-white text-lg font-devanagari shadow-sm" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-[#7B1E1E] uppercase tracking-wider ml-4">जन्म समय (Time)</label>
                    <input type="time" value={formData.tob} onChange={(e) => setFormData({...formData, tob: e.target.value})} className="w-full px-8 py-4 rounded-xl border border-[#D4AF37]/20 focus:border-[#D4AF37] focus:ring-0 bg-white text-lg font-devanagari shadow-sm" />
                  </div>
                </div>

                <button onClick={generateKundali} disabled={!formData.name} className="gold-gradient text-white px-16 py-6 rounded-full text-xl font-black shadow-[0_20px_40px_rgba(212,175,55,0.3)] hover:scale-105 transition-all disabled:opacity-50 font-devanagari tracking-wider flex items-center mx-auto gap-4">
                  <span className="text-2xl">🕉️</span> कुंडली बनाएँ
                </button>
              </div>
            )}
          </div>
        )}

        {step === 2 && data && (
          <div className="flex flex-col h-full animate-fade-in">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between p-6 border-b border-[#D4AF37]/10 bg-white/80 backdrop-blur-md sticky top-0 z-20">
              <div className="flex items-center space-x-4 mb-4 md:mb-0">
                 <div className="w-12 h-12 bg-[#7B1E1E] text-white rounded-full flex items-center justify-center font-bold text-xl">
                    {data.meta.name.charAt(0)}
                 </div>
                 <div>
                    <h2 className="text-xl font-devanagari font-bold text-[#7B1E1E]">{data.meta.name}</h2>
                    <p className="text-xs text-gray-500 font-devanagari">
                       {data.meta.dob} • {data.meta.tob} • {data.meta.place}
                    </p>
                 </div>
              </div>

              <div className="flex overflow-x-auto gap-2 p-1 bg-[#FFF8E7] rounded-full border border-[#D4AF37]/20 custom-scrollbar">
                {[
                  { id: 'chart', label: 'चक्र (Charts)' },
                  { id: 'planets', label: 'ग्रह स्पष्ट' },
                  { id: 'ashtakvarga', label: 'अष्टकवर्ग' },
                  { id: 'dasha', label: 'दशा' },
                  { id: 'dosha', label: 'दोष' },
                  { id: 'remedies', label: 'उपाय' },
                  { id: 'prediction', label: 'फलादेश' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as TabType)}
                    className={`px-6 py-2 rounded-full font-bold text-sm font-devanagari transition-all whitespace-nowrap ${
                      activeTab === tab.id 
                      ? 'gold-gradient text-white shadow-md' 
                      : 'text-[#7B1E1E]/70 hover:bg-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              <button onClick={() => { setStep(1); setData(null); }} className="hidden md:block ml-4 text-gray-400 hover:text-red-500">✕</button>
            </div>

            <div className="flex-1 overflow-y-auto bg-[#FAFAFA] p-6 custom-scrollbar">
              
              {/* --- CHARTS --- */}
              {activeTab === 'chart' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                   {/* Left: Chart Visualization */}
                   <div className="lg:col-span-7 flex flex-col items-center">
                      <div className="flex space-x-4 mb-6">
                         {(['D1', 'D9', 'Chandra'] as ChartType[]).map(c => (
                            <button 
                              key={c}
                              onClick={() => setActiveChart(c)}
                              className={`px-4 py-2 rounded-lg font-bold text-sm transition-all ${activeChart === c ? 'bg-[#7B1E1E] text-white' : 'bg-white border text-[#7B1E1E]'}`}
                            >
                               {c === 'D1' ? 'लग्न (D1)' : c === 'D9' ? 'नवांश (D9)' : 'चंद्र कुंडली'}
                            </button>
                         ))}
                      </div>
                      <div className="w-full max-w-xl aspect-square bg-white p-2 rounded-[2rem] shadow-2xl border-4 border-[#7B1E1E]">
                         <DynamicChart chartType={activeChart} chartData={data.charts} />
                      </div>
                   </div>

                   {/* Right: Avakahada & Yogas */}
                   <div className="lg:col-span-5 space-y-6">
                      <div className="bg-white p-6 rounded-[2rem] shadow-lg border border-[#D4AF37]/10">
                         <h3 className="text-[#7B1E1E] font-bold text-lg mb-4 border-b pb-2">अवकहड़ा चक्र</h3>
                         <div className="grid grid-cols-2 gap-y-3 text-sm">
                            {Object.entries(data.avakahada).map(([k, v]) => (
                               k !== 'lagna_rashi_no' && (
                                  <div key={k} className="flex justify-between">
                                     <span className="text-gray-500 capitalize">{k}</span>
                                     <span className="font-bold text-[#7B1E1E]">{v}</span>
                                  </div>
                               )
                            ))}
                         </div>
                      </div>
                      
                      <div className="bg-[#FFF8E7] p-6 rounded-[2rem] border border-[#D4AF37]/20">
                         <h3 className="text-[#7B1E1E] font-bold text-lg mb-4">विशेष योग (Yogas)</h3>
                         <div className="space-y-4">
                            {data.yogas.map((yoga, i) => (
                               <div key={i} className="bg-white p-4 rounded-xl shadow-sm">
                                  <p className="font-bold text-[#D4AF37]">{yoga.name}</p>
                                  <p className="text-xs text-gray-600 mt-1">{yoga.description}</p>
                               </div>
                            ))}
                         </div>
                      </div>
                   </div>
                </div>
              )}

              {/* --- PLANETS --- */}
              {activeTab === 'planets' && (
                <div className="bg-white rounded-[2rem] shadow-xl overflow-hidden border border-[#D4AF37]/10">
                   <div className="overflow-x-auto">
                      <table className="w-full text-left">
                         <thead className="bg-[#7B1E1E] text-white font-devanagari">
                            <tr>
                               <th className="p-4 font-bold">ग्रह</th>
                               <th className="p-4 font-bold">राशि</th>
                               <th className="p-4 font-bold">अंश (Degree)</th>
                               <th className="p-4 font-bold">नक्षत्र</th>
                               <th className="p-4 font-bold">चरण</th>
                               <th className="p-4 font-bold">भाव</th>
                               <th className="p-4 font-bold">स्थिति</th>
                               <th className="p-4 font-bold">गति</th>
                            </tr>
                         </thead>
                         <tbody className="divide-y divide-gray-100 font-devanagari">
                            {data.planets.map((p, i) => (
                               <tr key={i} className="hover:bg-[#FFF8E7]/50">
                                  <td className="p-4 font-bold text-[#7B1E1E]">
                                     {p.name} 
                                     {p.isRetro && <span className="ml-1 text-[10px] bg-red-100 text-red-600 px-1 rounded">(व)</span>}
                                     {p.isCombust && <span className="ml-1 text-[10px] bg-orange-100 text-orange-600 px-1 rounded">(अस्त)</span>}
                                  </td>
                                  <td className="p-4">{p.rashi}</td>
                                  <td className="p-4 font-mono text-sm">{p.degree}</td>
                                  <td className="p-4 text-[#D4AF37] font-bold">{p.nakshatra}</td>
                                  <td className="p-4 pl-6">{p.pada}</td>
                                  <td className="p-4 pl-6">{p.house}</td>
                                  <td className="p-4">
                                     <span className={`px-2 py-1 rounded text-xs text-white ${
                                        p.dignity.includes('Exalted') || p.dignity.includes('Own') ? 'bg-green-600' : 'bg-gray-400'
                                     }`}>{p.dignity}</span>
                                  </td>
                                  <td className="p-4 text-xs">{p.speed}</td>
                               </tr>
                            ))}
                         </tbody>
                      </table>
                   </div>
                </div>
              )}

              {/* --- ASHTAKVARGA --- */}
              {activeTab === 'ashtakvarga' && (
                 <div className="max-w-4xl mx-auto">
                    <div className="bg-white p-8 rounded-[2rem] shadow-xl text-center">
                       <h3 className="text-xl font-bold text-[#7B1E1E] mb-6">सर्वाष्टकवर्ग (Sarvashtakvarga)</h3>
                       <div className="grid grid-cols-6 md:grid-cols-12 gap-2">
                          {[...Array(12)].map((_, i) => (
                             <div key={i} className="flex flex-col">
                                <div className="bg-[#7B1E1E] text-white py-2 rounded-t-lg text-xs font-bold">भाव {i+1}</div>
                                <div className={`py-4 border-b border-l border-r rounded-b-lg font-bold text-xl ${
                                   (data.ashtakvarga[i+1] || 0) >= 28 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                                }`}>
                                   {data.ashtakvarga[i+1] || 0}
                                </div>
                             </div>
                          ))}
                       </div>
                       <p className="mt-6 text-sm text-gray-500">
                          * 28 से अधिक अंक वाले भाव अत्यंत शुभ परिणाम देते हैं।
                       </p>
                    </div>
                 </div>
              )}

              {/* --- DASHA --- */}
              {activeTab === 'dasha' && (
                 <div className="max-w-3xl mx-auto text-center mt-10">
                    <div className="w-24 h-24 bg-[#FFF8E7] rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-[#D4AF37] text-4xl">⏳</div>
                    <h3 className="text-2xl font-bold font-devanagari text-[#7B1E1E] mb-2">विंशोत्तरी दशा</h3>
                    <p className="text-gray-500 mb-10">आपके जीवन का वर्तमान कालचक्र</p>
                    
                    <div className="bg-white p-10 rounded-[3rem] shadow-2xl border border-gray-100 relative overflow-hidden">
                       <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-[#7B1E1E] to-[#D4AF37]"></div>
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
                          <div>
                             <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">महादशा</p>
                             <p className="text-4xl font-bold text-[#7B1E1E] font-devanagari mt-2">{data.dasha.current_mahadasha}</p>
                          </div>
                          <div className="hidden md:block text-3xl text-gray-200">➔</div>
                          <div>
                             <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">अंतरदशा</p>
                             <p className="text-4xl font-bold text-[#D4AF37] font-devanagari mt-2">{data.dasha.current_antardasha}</p>
                          </div>
                       </div>
                       <div className="mt-8 pt-8 border-t border-gray-100">
                          <p className="text-lg font-bold text-gray-600">
                             समाप्ति: <span className="text-[#7B1E1E]">{data.dasha.end_date}</span>
                          </p>
                       </div>
                    </div>
                 </div>
              )}

              {/* --- DOSHA --- */}
              {activeTab === 'dosha' && (
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
                    {[
                       { title: 'मंगल दोष', data: data.doshas.mangal, icon: '🔥' },
                       { title: 'काल सर्प दोष', data: data.doshas.kaal_sarp, icon: '🐍' },
                       { title: 'पितृ दोष', data: data.doshas.pitra, icon: '🙏' },
                       { title: 'साढ़े साती', data: { present: data.doshas.sade_sati.status, description: data.doshas.sade_sati.description }, icon: '🪐' }
                    ].map((item, i) => (
                       <div key={i} className={`p-8 rounded-[2.5rem] border-2 transition-all ${item.data.present ? 'bg-red-50 border-red-100' : 'bg-green-50 border-green-100'}`}>
                          <div className="flex items-center justify-between mb-4">
                             <div className="flex items-center space-x-4">
                                <span className="text-3xl">{item.icon}</span>
                                <h3 className="text-xl font-bold font-devanagari text-[#7B1E1E]">{item.title}</h3>
                             </div>
                             <span className={`px-3 py-1 rounded-full text-xs font-bold text-white ${item.data.present ? 'bg-red-500' : 'bg-green-500'}`}>
                                {item.data.present ? 'उपस्थित' : 'अनुपस्थित'}
                             </span>
                          </div>
                          <p className="text-gray-600 font-devanagari text-sm leading-relaxed">
                             {item.data.description}
                          </p>
                       </div>
                    ))}
                 </div>
              )}

              {/* --- REMEDIES --- */}
              {activeTab === 'remedies' && (
                 <div className="max-w-4xl mx-auto space-y-6">
                    <div className="bg-[#FFF8E7] p-8 rounded-[2rem] border border-[#D4AF37]/20 flex items-start gap-6">
                       <div className="text-4xl">💎</div>
                       <div>
                          <h4 className="font-bold text-[#7B1E1E] text-lg mb-2">भाग्य रत्न (Gemstone)</h4>
                          <p className="text-gray-700 font-devanagari">{data.remedies.gemstone}</p>
                       </div>
                    </div>
                    <div className="bg-[#FFF8E7] p-8 rounded-[2rem] border border-[#D4AF37]/20 flex items-start gap-6">
                       <div className="text-4xl">📿</div>
                       <div>
                          <h4 className="font-bold text-[#7B1E1E] text-lg mb-2">रुद्राक्ष (Rudraksha)</h4>
                          <p className="text-gray-700 font-devanagari">{data.remedies.rudraksha}</p>
                       </div>
                    </div>
                    <div className="bg-[#FFF8E7] p-8 rounded-[2rem] border border-[#D4AF37]/20 flex items-start gap-6">
                       <div className="text-4xl">🕉️</div>
                       <div>
                          <h4 className="font-bold text-[#7B1E1E] text-lg mb-2">मंत्र (Mantra)</h4>
                          <p className="text-gray-700 font-devanagari font-bold">{data.remedies.mantra}</p>
                       </div>
                    </div>
                    <div className="text-center pt-8">
                       <button className="gold-gradient text-white px-10 py-4 rounded-full font-bold shadow-xl">
                          उपाय सामग्री आर्डर करें
                       </button>
                    </div>
                 </div>
              )}

              {/* --- PREDICTION --- */}
              {activeTab === 'prediction' && (
                 <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                    {[
                      { title: 'व्यक्तित्व', text: data.prediction.personality },
                      { title: 'करियर', text: data.prediction.career },
                      { title: 'आर्थिक स्थिति', text: data.prediction.finance },
                      { title: 'स्वास्थ्य', text: data.prediction.health },
                      { title: 'विवाह', text: data.prediction.marriage }
                    ].map((section, idx) => (
                       <div key={idx} className={`bg-white p-8 rounded-[2rem] shadow-lg border-l-4 border-[#D4AF37] ${idx === 4 ? 'md:col-span-2' : ''}`}>
                          <h3 className="text-xl font-bold font-devanagari text-[#7B1E1E] mb-4">{section.title}</h3>
                          <p className="text-gray-600 font-devanagari leading-relaxed">{section.text}</p>
                       </div>
                    ))}
                    <div className="md:col-span-2 text-center pt-8">
                       <button className="bg-[#7B1E1E] text-white px-10 py-4 rounded-full font-bold shadow-xl hover:bg-[#A00000] transition-colors">
                          📄 PDF रिपोर्ट डाउनलोड करें
                       </button>
                    </div>
                 </div>
              )}

            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default KundaliPage;
