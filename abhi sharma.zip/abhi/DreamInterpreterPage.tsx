
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Language } from '../types';
import { DIVINE_ICONS, DREAM_INTERPRETER_INFO } from '../constants';

const DreamInterpreterPage: React.FC<{ language: Language }> = ({ language }) => {
  const [dreamText, setDreamText] = useState('');
  const [interpretation, setInterpretation] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const interpretDream = async () => {
    if (!dreamText.trim()) return;
    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
      const prompt = `Interpret this dream based on Vedic Swapna Shastra: "${dreamText}". Provide a spiritual meaning, whether it's auspicious or inauspicious, and a small remedy if needed. Use ${language === 'hi' ? 'Hindi' : 'English'}. Tone: Mystical, wise, and comforting.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { systemInstruction: "You are a master of Vedic Swapna Shastra (Dream Science) from Ujjain." }
      });
      setInterpretation(response.text || '');
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-[#0a0a0c] min-h-screen text-white relative overflow-hidden">
      {/* Mystical Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#1a1a2e_0%,#0a0a0c_100%)] opacity-80"></div>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full opacity-10 pointer-events-none">
        <DIVINE_ICONS.Om className="w-full h-full text-[#D4AF37]" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10 text-center">
        <span className="text-[#D4AF37] font-black text-xs tracking-[0.5em] uppercase mb-4 block animate-pulse">Ancient Secrets</span>
        <h1 className="text-5xl md:text-8xl font-devanagari font-bold mb-6 gold-glow shlok-mask">
          {language === 'hi' ? DREAM_INTERPRETER_INFO.title.hi : DREAM_INTERPRETER_INFO.title.en}
        </h1>
        <p className="text-xl text-gray-400 font-devanagari italic mb-16">
          {language === 'hi' ? DREAM_INTERPRETER_INFO.subtitle.hi : DREAM_INTERPRETER_INFO.subtitle.en}
        </p>

        {!interpretation ? (
          <div className="bg-white/5 backdrop-blur-3xl p-10 md:p-16 rounded-[4rem] border border-white/10 shadow-2xl animate-fade-in">
            <textarea 
              value={dreamText}
              onChange={(e) => setDreamText(e.target.value)}
              placeholder={language === 'hi' ? 'अपने सपने का वर्णन करें...' : 'Describe your dream here...'}
              className="w-full h-48 bg-black/40 rounded-[2rem] p-8 border-2 border-white/5 focus:border-[#D4AF37]/40 focus:ring-0 text-xl text-white mb-10 transition-all placeholder:opacity-30"
            />
            <button 
              onClick={interpretDream}
              disabled={isLoading || !dreamText.trim()}
              className="gold-gradient text-white px-16 py-6 rounded-full text-xl font-black shadow-2xl hover:scale-105 transition-all disabled:opacity-30"
            >
              {isLoading ? (
                <div className="flex items-center space-x-3">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>{language === 'hi' ? 'विश्लेषण जारी है...' : 'Analyzing...'}</span>
                </div>
              ) : (
                <span>{language === 'hi' ? 'रहस्य जानें' : 'Reveal Secrets'}</span>
              )}
            </button>
          </div>
        ) : (
          <div className="bg-white/5 backdrop-blur-3xl p-10 md:p-16 rounded-[4rem] border border-[#D4AF37]/20 shadow-[0_0_100px_rgba(212,175,55,0.1)] animate-reveal text-left relative">
             <button 
                onClick={() => setInterpretation('')}
                className="absolute top-8 right-8 text-white/40 hover:text-white transition-colors"
             >
                ✕
             </button>
             <div className="flex items-center space-x-6 mb-10 pb-6 border-b border-white/10">
                <div className="w-16 h-16 bg-[#D4AF37]/20 rounded-2xl flex items-center justify-center text-3xl">🌙</div>
                <h3 className="text-3xl font-devanagari font-bold text-[#D4AF37]">सपनों का संकेत (The Divine Meaning)</h3>
             </div>
             <div className="prose prose-invert prose-xl max-w-none text-gray-200 italic leading-relaxed whitespace-pre-wrap font-medium">
                {interpretation}
             </div>
             <div className="mt-16 text-center">
                <button 
                  onClick={() => setInterpretation('')}
                  className="bg-white/10 border border-white/20 px-10 py-4 rounded-full font-bold hover:bg-white hover:text-black transition-all"
                >
                   {language === 'hi' ? 'एक और सपना साझा करें' : 'Interpret Another Dream'}
                </button>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DreamInterpreterPage;
