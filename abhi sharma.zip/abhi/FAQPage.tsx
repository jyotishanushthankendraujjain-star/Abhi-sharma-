
import React, { useState } from 'react';
import { Language } from '../types';
import { FAQ_DATA, DIVINE_ICONS } from '../constants';

const FAQPage: React.FC<{ language: Language }> = ({ language }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-[#FFF8E7] min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">जिज्ञासा समाधान</span>
          <h1 className="text-4xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6 shlok-mask">
            {language === 'hi' ? 'अक्सर पूछे जाने वाले प्रश्न' : 'Common Questions'}
          </h1>
          <div className="flex items-center justify-center space-x-4 opacity-30">
            <div className="h-px w-16 bg-[#7B1E1E]"></div>
            <DIVINE_ICONS.Trishul className="w-8 h-8 text-[#D4AF37]" />
            <div className="h-px w-16 bg-[#7B1E1E]"></div>
          </div>
        </div>

        <div className="space-y-6">
          {FAQ_DATA.map((faq, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-[2.5rem] overflow-hidden shadow-xl border-2 transition-all duration-500 ${openIndex === index ? 'border-[#D4AF37] shadow-[#D4AF37]/10' : 'border-transparent hover:border-[#D4AF37]/20'}`}
            >
              <button 
                onClick={() => toggleAccordion(index)}
                className="w-full px-8 md:px-12 py-8 flex items-center justify-between text-left group"
              >
                <span className={`text-xl md:text-2xl font-devanagari font-bold transition-colors duration-300 ${openIndex === index ? 'text-[#D4AF37]' : 'text-[#7B1E1E]'}`}>
                  {language === 'hi' ? faq.question.hi : faq.question.en}
                </span>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 ${openIndex === index ? 'bg-[#D4AF37] text-white rotate-180' : 'bg-[#FFF8E7] text-[#D4AF37] group-hover:scale-110'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>
              
              <div className={`overflow-hidden transition-all duration-700 ease-[cubic-bezier(0.16, 1, 0.3, 1)] ${openIndex === index ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'}`}>
                <div className="px-8 md:px-12 pb-10">
                  <div className="h-px w-full bg-[#D4AF37]/10 mb-8"></div>
                  <p className="text-lg md:text-xl font-devanagari text-gray-600 leading-relaxed italic border-l-4 border-[#D4AF37] pl-6">
                    {language === 'hi' ? faq.answer.hi : faq.answer.en}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Spiritual Support Section */}
        <div className="mt-24 p-12 md:p-16 rounded-[4rem] bg-[#7B1E1E] text-white text-center relative overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#A00000_0%,#7B1E1E_100%)]"></div>
          <div className="absolute top-0 right-0 opacity-[0.05] translate-x-1/4 -translate-y-1/4 group-hover:scale-110 transition-transform duration-[3s]">
            <DIVINE_ICONS.Om className="w-96 h-96" />
          </div>
          
          <div className="relative z-10">
            <h3 className="text-3xl md:text-5xl font-devanagari font-bold mb-6">
              {language === 'hi' ? 'अभी भी कोई प्रश्न है?' : 'Still have questions?'}
            </h3>
            <p className="text-xl md:text-2xl font-devanagari opacity-80 mb-10 max-w-2xl mx-auto italic">
              {language === 'hi' ? 'महादेव की कृपा से आपकी हर जिज्ञासा का समाधान हमारे पास है।' : 'With Mahakal\'s grace, we have the solution to all your queries.'}
            </p>
            <button className="gold-gradient px-12 py-5 rounded-full font-black text-xl shadow-2xl hover:scale-105 active:scale-95 transition-all">
              {language === 'hi' ? 'पंडित जी से संपर्क करें' : 'Contact Pandit Ji'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;
