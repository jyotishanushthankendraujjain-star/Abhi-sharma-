
import React, { useState, useEffect } from 'react';
import { Language } from '../types';
import { KUMBH_MELA_DATA, DIVINE_ICONS } from '../constants';

const KumbhMelaPage: React.FC<{ language: Language }> = ({ language }) => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const timer = setInterval(() => {
      const start = new Date(KUMBH_MELA_DATA.startDate).getTime();
      const now = new Date().getTime();
      const diff = start - now;

      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="pt-20 bg-black text-white min-h-screen relative overflow-hidden">
      {/* Background Cinematic Visual */}
      <div className="absolute inset-0 opacity-40">
        <img 
          src="https://images.unsplash.com/photo-1590766940554-634a7ed41450?q=80&w=2000" 
          alt="Holy Kshipra" 
          className="w-full h-full object-cover grayscale"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-24 flex flex-col items-center text-center">
        <div className="animate-float mb-8">
           <DIVINE_ICONS.Trishul className="w-24 h-24 text-[#D4AF37]" />
        </div>
        
        <h1 className="text-6xl md:text-9xl font-devanagari font-bold mb-6 gold-glow shlok-mask leading-tight">
          {language === 'hi' ? KUMBH_MELA_DATA.title.hi : KUMBH_MELA_DATA.title.en}
        </h1>
        <p className="text-xl md:text-3xl font-devanagari italic text-[#D4AF37] mb-16 tracking-widest opacity-80">
          {language === 'hi' ? KUMBH_MELA_DATA.subtitle.hi : KUMBH_MELA_DATA.subtitle.en}
        </p>

        {/* Cinematic Countdown */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-24 w-full max-w-5xl">
          {[
            { label: language === 'hi' ? 'दिन' : 'Days', value: timeLeft.days },
            { label: language === 'hi' ? 'घंटे' : 'Hours', value: timeLeft.hours },
            { label: language === 'hi' ? 'मिनट' : 'Minutes', value: timeLeft.minutes },
            { label: language === 'hi' ? 'सेकंड' : 'Seconds', value: timeLeft.seconds },
          ].map((item, i) => (
            <div key={i} className="bg-white/5 backdrop-blur-3xl border border-white/10 p-10 rounded-[3rem] shadow-2xl group hover:border-[#D4AF37]/40 transition-all">
              <span className="text-5xl md:text-7xl font-playfair font-black text-white block mb-4 group-hover:text-[#D4AF37] transition-colors">
                {item.value}
              </span>
              <span className="text-xs font-black tracking-[0.4em] uppercase text-[#D4AF37]/60">
                {item.label}
              </span>
            </div>
          ))}
        </div>

        <div className="max-w-3xl mb-20">
          <p className="text-2xl md:text-3xl font-devanagari leading-relaxed text-gray-300 italic">
            “{language === 'hi' ? KUMBH_MELA_DATA.description.hi : KUMBH_MELA_DATA.description.en}”
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          <button className="gold-gradient text-white px-16 py-6 rounded-full text-xl font-black shadow-[0_20px_60px_rgba(212,175,55,0.3)] hover:scale-105 transition-all uppercase tracking-widest">
            {language === 'hi' ? 'कुंभ संकल्प पंजीकरण' : 'Kumbh Sankalp Registration'}
          </button>
          <button className="bg-white/10 backdrop-blur-xl border border-white/20 px-16 py-6 rounded-full text-xl font-black hover:bg-white hover:text-black transition-all">
            {language === 'hi' ? 'महत्व जानें' : 'Explore Significance'}
          </button>
        </div>

        <div className="mt-40 opacity-20">
           <DIVINE_ICONS.Om className="w-60 h-60 text-white animate-flicker" />
        </div>
      </div>
    </div>
  );
};

export default KumbhMelaPage;
