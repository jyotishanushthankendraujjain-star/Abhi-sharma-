
import React from 'react';
import { Language } from '../types';
import { SERVICES_DATA } from '../constants';

const ServicesPage: React.FC<{ language: Language; onBook: (service: string) => void }> = ({ language, onBook }) => {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-[#D4AF37] font-bold text-sm tracking-[0.3em] uppercase">Vedic Rituals</span>
          <h1 className="text-4xl md:text-6xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6">
            {language === 'hi' ? 'हमारी प्रमुख सेवाएं' : 'Our Specialized Services'}
          </h1>
          <div className="flex items-center justify-center space-x-4 opacity-40">
            <div className="h-[1px] w-12 bg-[#7B1E1E]"></div>
            <span className="text-xl">🕉️</span>
            <div className="h-[1px] w-12 bg-[#7B1E1E]"></div>
          </div>
          <p className="mt-8 text-gray-500 max-w-2xl mx-auto italic">
            {language === 'hi' 
              ? 'उज्जैन के सिद्ध विद्वानों द्वारा संपन्न कराए जाने वाले समस्त धार्मिक अनुष्ठान एवं ज्योतिषीय समाधान।' 
              : 'All religious rituals and astrological solutions performed by expert scholars of Ujjain.'}
          </p>
        </div>

        <div className="space-y-24">
          {SERVICES_DATA.map((category, idx) => (
            <div key={category.id} className="relative">
              <div className="flex items-center mb-10 sticky top-24 bg-white/95 backdrop-blur-sm z-10 py-4 border-b border-[#D4AF37]/10">
                <span className="text-4xl mr-6 opacity-30 font-bold font-playfair">{String(idx + 1).padStart(2, '0')}</span>
                <h2 className="text-2xl md:text-3xl font-devanagari font-bold text-[#7B1E1E]">
                  {language === 'hi' ? category.name.hi : category.name.en}
                </h2>
                <div className="flex-1 h-[1px] bg-gradient-to-r from-[#D4AF37]/40 to-transparent ml-6"></div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {category.items.map((item) => (
                  <div 
                    key={item.id} 
                    className="bg-[#FFF8E7]/20 p-6 rounded-[2rem] border border-[#D4AF37]/10 hover:border-[#D4AF37] hover:bg-white hover:shadow-[0_20px_40px_rgba(212,175,55,0.12)] transition-all duration-500 group cursor-pointer relative overflow-hidden"
                  >
                    {/* Subtle shine effect on hover */}
                    <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/40 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 pointer-events-none"></div>

                    <div className="flex items-start justify-between mb-6">
                      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-2xl border border-[#D4AF37]/20 shadow-sm group-hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] group-hover:rotate-[360deg] transition-all duration-700">
                        <span className="group-hover:scale-125 transition-transform duration-500">
                           {category.id === 'jyotish' ? '🕉️' : 
                            category.id === 'ujjain_vishesh' ? '🔱' : 
                            category.id === 'shakti_tantra' ? '🔥' : 
                            category.id === 'path_seva' ? '📖' : 
                            category.id === 'jap_seva' ? '📿' : 
                            category.id === 'dosh_nivaran' ? '⚔️' : 
                            category.id === 'pitru_moksha' ? '🙏' : 
                            category.id === 'ved_puran' ? '📜' : 
                            category.id === 'katha_seva' ? '🗣️' : '✨'}
                        </span>
                      </div>
                      <div className="text-[10px] font-bold text-[#D4AF37]/60 tracking-tighter bg-[#D4AF37]/5 px-2 py-1 rounded-full border border-[#D4AF37]/10 uppercase">
                        Premium
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-devanagari font-bold text-[#7B1E1E] mb-4 leading-tight group-hover:text-[#D4AF37] transition-colors duration-300 min-h-[3rem]">
                      {language === 'hi' ? item.title.hi : item.title.en}
                    </h3>
                    
                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-[#D4AF37]/5">
                      <span className="text-[10px] text-gray-400 uppercase tracking-widest font-bold flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 mr-2 animate-pulse"></span>
                        {language === 'hi' ? 'उपलब्ध' : 'Available'}
                      </span>
                      <button 
                        onClick={() => onBook(language === 'hi' ? item.title.hi : item.title.en)}
                        className="text-xs font-bold text-[#7B1E1E] group-hover:text-[#D4AF37] flex items-center transition-all"
                      >
                        <span className="mr-2">{language === 'hi' ? 'बुक करें' : 'Book Now'}</span>
                        <span className="group-hover:translate-x-1 transition-transform">→</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;
