
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

const VedicAIPage: React.FC<{ language: Language }> = ({ language }) => {
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
          systemInstruction: `You are a highly knowledgeable Vedic Scholar and Pandit from Ujjain. Your tone is divine, calm, and deeply respectful. Answer questions about Hindu rituals, Ujjain's significance, Jyotish, and spirituality. Use Hindi or English as requested. Always start with a spiritual blessing. Your name is 'Pandit ji'.`,
        }
      });

      setMessages(prev => [...prev, { role: 'model', text: response.text || 'क्षमा करें, मैं अभी समझ नहीं पाया।' }]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-[#FFF8E7] min-h-screen">
      <div className="max-w-4xl mx-auto flex flex-col h-[75vh] bg-white rounded-[3rem] divine-shadow border border-[#D4AF37]/20 overflow-hidden relative">
        {/* Background Watermark */}
        <div className="absolute inset-0 opacity-[0.02] pointer-events-none flex items-center justify-center">
          <DIVINE_ICONS.Om className="w-[400px] h-[400px] text-[#7B1E1E]" />
        </div>

        {/* Header */}
        <div className="p-8 border-b border-[#D4AF37]/10 flex items-center justify-between bg-white/80 backdrop-blur-md relative z-10">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#FFF1B8] rounded-full flex items-center justify-center text-2xl border border-[#D4AF37]/20 animate-flicker">
              🔱
            </div>
            <div>
              <h2 className="text-xl font-devanagari font-bold text-[#7B1E1E]">
                {language === 'hi' ? 'वैदिक AI सहायक' : 'Vedic AI Assistant'}
              </h2>
              <p className="text-[10px] text-[#D4AF37] font-bold tracking-widest uppercase">Pandit ji • Online</p>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-8 space-y-6 relative z-10">
          {messages.length === 0 && (
            <div className="text-center py-20 opacity-40">
              <DIVINE_ICONS.Lotus className="w-20 h-20 mx-auto text-[#D4AF37] mb-6" />
              <p className="text-lg font-devanagari italic">
                {language === 'hi' ? 'पूछिये पंडित जी से अपनी समस्या या जिज्ञासा...' : 'Ask Pandit ji about your concerns or curiosity...'}
              </p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-6 rounded-[2rem] ${
                m.role === 'user' 
                ? 'bg-[#7B1E1E] text-white shadow-xl rounded-tr-none' 
                : 'bg-[#FFF8E7] text-[#7B1E1E] border border-[#D4AF37]/20 rounded-tl-none font-medium'
              }`}>
                {m.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-[#FFF8E7] p-4 rounded-full animate-pulse flex space-x-2">
                <div className="w-2 h-2 bg-[#D4AF37] rounded-full"></div>
                <div className="w-2 h-2 bg-[#D4AF37] rounded-full"></div>
                <div className="w-2 h-2 bg-[#D4AF37] rounded-full"></div>
              </div>
            </div>
          )}
          <div ref={scrollRef} />
        </div>

        {/* Input */}
        <div className="p-6 bg-white border-t border-[#D4AF37]/10 relative z-10">
          <div className="flex bg-[#FFF8E7] rounded-full p-2 border border-[#D4AF37]/20 shadow-inner">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              placeholder={language === 'hi' ? 'अपना प्रश्न यहाँ लिखें...' : 'Type your question here...'}
              className="flex-1 bg-transparent border-none focus:ring-0 px-6 font-medium text-[#7B1E1E]"
            />
            <button 
              onClick={sendMessage}
              className="gold-gradient w-12 h-12 rounded-full flex items-center justify-center text-white shadow-lg hover:scale-105 transition-transform"
            >
              🔱
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VedicAIPage;
