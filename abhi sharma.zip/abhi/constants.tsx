
import React from 'react';
import { ServiceCategory, RashiData, Product } from './types';

// API Configuration
export const KUNDALI_API_KEY = "K4AaOlASZu3PEFOFPsD7X9GvqfRz3MrA45goz75D";

export const COLORS = {
  primaryGold: '#D4AF37',
  pureWhite: '#FFFFFF',
  lightCream: '#FFF8E7',
  softYellowGlow: '#FFF1B8',
  templeMaroon: '#7B1E1E',
  deepRed: '#A00000',
  bhasmaGrey: '#EDEDED',
  trishulSilver: '#BFC1C2',
  shivBlue: '#2C4A6E',
};

export const DIVINE_ICONS = {
  Om: ({ className = "w-8 h-8" }: { className?: string }) => (
    <svg viewBox="0 0 100 100" className={`${className} fill-current`} xmlns="http://www.w3.org/2000/svg">
       <path d="M50 10c-5.5 0-10 4.5-10 10s4.5 10 10 10 10-4.5 10-10-4.5-10-10-10zm0 15c-2.8 0-5-2.2-5-5s2.2-5 5-5 5 2.2 5 5-2.2 5-5 5zm0 10c-16.6 0-30 13.4-30 30s13.4 30 30 30 30-13.4 30-30-13.4-30-30-30zm0 55c-13.8 0-25-11.2-25-25s11.2-25 25-25 25 11.2 25 25-11.2 25-25 25zm-5-30h10v10h-10v-10zm0-10h10v5h-10v-5z"/>
    </svg>
  ),
  Trishul: ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg viewBox="0 0 24 24" className={`${className} fill-current`} xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L13 6H17L13 8L14 12L12 10L10 12L11 8L7 6H11L12 2ZM11 13V22H13V13H17V15H19V11H13V10H11V11H5V15H7V13H11Z"/>
    </svg>
  ),
  Damru: ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg viewBox="0 0 24 24" className={`${className} fill-current`} xmlns="http://www.w3.org/2000/svg">
      <path d="M6 4C6 4 8 8 12 8C16 8 18 4 18 4V20C18 20 16 16 12 16C8 16 6 20 6 20V4ZM12 9C9.5 9 8 7.5 7.2 6.5C8 7.5 10 8.5 12 8.5C14 8.5 16 7.5 16.8 6.5C16 7.5 14.5 9 12 9Z"/>
    </svg>
  ),
  Lotus: ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg viewBox="0 0 24 24" className={`${className} fill-current`} xmlns="http://www.w3.org/2000/svg">
      <path d="M12 22C12 22 17 18 17 13C17 10 15 8 12 8C9 8 7 10 7 13C7 18 12 22 12 22ZM12 5C14 5 15.5 6.5 15.5 8.5C15.5 10.5 14 12 12 12C10 12 8.5 10.5 8.5 8.5C8.5 6.5 10 5 12 5ZM12 2C13 2 14 3 14 4.5C14 6 13 7 12 7C11 7 10 6 10 4.5C10 3 11 2 12 2Z"/>
    </svg>
  )
};

export const DEITY_GALLERY = [
  { id: 1, name: { hi: "श्री गणेश", en: "Lord Ganesha" }, image: "https://images.unsplash.com/photo-1544111309-8b2097e887e4?q=80&w=1200" },
  { id: 2, name: { hi: "महाकाल शिव", en: "Mahakal Shiva" }, image: "https://images.unsplash.com/photo-1619124441416-f283594806a6?q=80&w=1200" },
  { id: 3, name: { hi: "माता लक्ष्मी", en: "Goddess Lakshmi" }, image: "https://images.unsplash.com/photo-1605784401368-5af1d9d6c4dc?q=80&w=1200" },
  { id: 4, name: { hi: "हनुमान जी", en: "Lord Hanuman" }, image: "https://images.unsplash.com/photo-1635345155465-98317789319e?q=80&w=1200" },
  { id: 5, name: { hi: "माता दुर्गा", en: "Goddess Durga" }, image: "https://images.unsplash.com/photo-1634842523294-811c7df0e76a?q=80&w=1200" },
  { id: 6, name: { hi: "श्री कृष्ण", en: "Lord Krishna" }, image: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?q=80&w=1200" }
];

export const PRODUCTS_DATA: Product[] = [
  { id: 'p1', name: { hi: 'सिद्ध रुद्राक्ष माला', en: 'Siddha Rudraksha Mala' }, price: 1100, image: 'https://images.unsplash.com/photo-1600880292089-90a7e086f0ed?q=80&w=800' },
  { id: 'p2', name: { hi: 'श्री यंत्र (तांबा)', en: 'Shree Yantra (Copper)' }, price: 2100, image: 'https://images.unsplash.com/photo-1614728263952-84ea206f99b6?q=80&w=800' },
  { id: 'p3', name: { hi: 'नवरत्न अंगूठी', en: 'Navratna Ring' }, price: 5100, image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=800' },
  { id: 'p4', name: { hi: 'पंचमुखी रुद्राक्ष', en: 'Panchmukhi Rudraksha' }, price: 501, image: 'https://images.unsplash.com/photo-1590004953392-5aba2e78319b?q=80&w=800' }
];

export const BLOG_DATA = [
  { 
    id: 1, 
    title: { hi: 'महाकाल भस्म आरती का आध्यात्मिक रहस्य', en: 'Spiritual Mystery of Mahakal Bhasm Aarti' },
    image: 'https://images.unsplash.com/photo-1590766940554-634a7ed41450?q=80&w=800',
    date: '2024-03-20'
  },
  { 
    id: 2, 
    title: { hi: 'उज्जैन: क्यों इसे पृथ्वी का नाभि केंद्र कहा जाता है?', en: 'Ujjain: Why is it called the Navel Center of Earth?' },
    image: 'https://images.unsplash.com/photo-1628104523091-81766627d353?q=80&w=800',
    date: '2024-03-15'
  }
];

export const FAQ_DATA = [
  {
    question: { hi: "भस्म आरती की बुकिंग कैसे करें?", en: "How to book Bhasm Aarti?" },
    answer: { hi: "भस्म आरती की बुकिंग आधिकारिक वेबसाइट के माध्यम से या श्री महाकालेश्वर मंदिर के ऑनलाइन पोर्टल द्वारा की जा सकती है।", en: "Bhasm Aarti booking is managed via the official Shree Mahakaleshwar temple portal." }
  },
  {
    question: { hi: "क्या आप ऑनलाइन संकल्प सुविधा देते हैं?", en: "Do you offer online Sankalp?" },
    answer: { hi: "हाँ, हम लाइव वीडियो कॉल के माध्यम से संकल्प और पूजा संपन्न कराते हैं।", en: "Yes, we perform rituals via live video calls for devotees worldwide." }
  },
  {
    question: { hi: "कालसर्प दोष निवारण हेतु उज्जैन क्यों?", en: "Why Ujjain for Kaal Sarp Dosh?" },
    answer: { hi: "उज्जैन को मंगल की जन्मभूमि और महाकाल की नगरी माना जाता है, यहाँ दोष निवारण अनंत फलदायी है।", en: "Ujjain is the birthplace of Mars and the city of Mahakal, making it the most potent site for dosha removal." }
  }
];

export const DARSHAN_DATA = [
  {
    id: 'mahakal',
    name: { hi: 'श्री महाकालेश्वर ज्योतिर्लिंग', en: 'Shree Mahakaleshwar Jyotirlinga' },
    image: 'https://images.unsplash.com/photo-1628104523091-81766627d353?q=80&w=1600',
    desc: { hi: 'स्वयंभू दक्षिणमुखी ज्योतिर्लिंग, जहाँ भस्म आरती का अद्वितीय दर्शन होता है।', en: 'The self-manifested south-facing Jyotirlinga, famous for its unique Bhasma Aarti.' }
  },
  {
    id: 'kshipra',
    name: { hi: 'पावन क्षिप्रा नदी - रामघाट', en: 'Holy Kshipra River - Ram Ghat' },
    image: 'https://images.unsplash.com/photo-1590766940554-634a7ed41450?q=80&w=1600',
    desc: { hi: 'अमृत की बूंदों से पावन नदी, जहाँ संध्या आरती की छटा दिव्य होती है।', en: 'The river purified by drops of nectar, famous for its divine evening Aarti.' }
  }
];

export const SERVICES_DATA: ServiceCategory[] = [
  {
    id: 'jyotish',
    name: { hi: '1. ज्योतिष सेवाएं', en: '1. Jyotish Services' },
    items: [
      { id: 'j1', title: { hi: 'जन्म कुंडली विश्लेषण', en: 'Birth Chart Analysis' } },
      { id: 'j2', title: { hi: 'विवाह मिलान', en: 'Marriage Matching' } },
      { id: 'j3', title: { hi: 'करियर और व्यापार ज्योतिष', en: 'Career & Business Astrology' } },
      { id: 'j10', title: { hi: 'ग्रह शांति उपाय', en: 'Graha Shanti Remedies' } },
    ]
  },
  {
    id: 'ujjain_vishesh',
    name: { hi: '2. उज्जैन विशेष सेवाएं', en: '2. Ujjain Special Services' },
    items: [
      { id: 'u1', title: { hi: 'महाकालेश्वर दर्शन व्यवस्था', en: 'Mahakaleshwar Darshan' } },
      { id: 'u3', title: { hi: 'भस्म आरती बुकिंग मार्गदर्शन', en: 'Bhasm Aarti Guide' } },
      { id: 'u6', title: { hi: 'रामघाट पूजन एवं अनुष्ठान', en: 'Ramghat Poojan' } },
    ]
  }
];

export const BHAKTI_SAGAR_DATA = {
  aarti: [
    { 
      deity: { hi: 'श्री गणेश', en: 'Lord Ganesha' }, 
      image: 'https://images.unsplash.com/photo-1544111309-8b2097e887e4?q=80&w=1200',
      title: { hi: 'जय गणेश जय गणेश देवा', en: 'Jai Ganesh Jai Ganesh Deva' }, 
      content: { 
        hi: 'जय गणेश जय गणेश जय गणेश देवा ।\nमाता जाकी पार्वती, पिता महादेवा ॥', 
        en: 'Jai Ganesh Jai Ganesh Jai Ganesh Deva.\nMata Jaki Parvati, Pita Mahadeva.' 
      } 
    }
  ],
  mantra: [
    {
      deity: { hi: 'श्री शिव', en: 'Lord Shiva' },
      image: 'https://images.unsplash.com/photo-1619124441416-f283594806a6?q=80&w=1200',
      title: { hi: 'महामृत्युंजय मंत्र', en: 'Mahamrityunjaya Mantra' },
      content: {
        hi: 'ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्।\nउर्वारुकमिव बन्धनान्मृत्योर्मुक्षीय माऽमृतात्॥',
        en: 'Om Tryambakam Yajamahe Sugandhim Pushti-Vardhanam\nUrvarukamiva Bandhanan Mrityor Mukshiya Maamritat'
      }
    },
    {
      deity: { hi: 'श्री गणेश', en: 'Lord Ganesha' },
      image: 'https://images.unsplash.com/photo-1544111309-8b2097e887e4?q=80&w=1200',
      title: { hi: 'वक्रतुण्ड महाकाय', en: 'Vakratunda Mahakaya' },
      content: {
        hi: 'वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ।\nनिर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा॥',
        en: 'Vakratunda Mahakaya Suryakoti Samaprabha\nNirvighnam Kuru Me Deva Sarvakaryeshu Sarvada'
      }
    }
  ],
  chalisa: [
    {
      deity: { hi: 'हनुमान जी', en: 'Lord Hanuman' },
      image: 'https://images.unsplash.com/photo-1635345155465-98317789319e?q=80&w=1200',
      title: { hi: 'श्री हनुमान चालीसा', en: 'Shree Hanuman Chalisa' },
      content: {
        hi: 'श्रीगुरु चरन सरोज रज, निज मनु मुकुरु सुधारि।\nबरनऊं रघुबर बिमल जसु, जो दायकु फल चारि॥\n\nबुद्धिहीन तनु जानिके, सुमिरौं पवन-कुमार।\nबल बुद्धि बिद्या देहु मोहिं, हरहु कलेस विकार॥',
        en: 'Shri Guru Charan Saroj Raj, Nij Manu Mukuru Sudhari\nBarnau Raghubar Bimal Jasu, Jo Dayaku Phal Chari'
      }
    }
  ],
  shlok: [
    {
      deity: { hi: 'गुरु', en: 'Guru' },
      image: 'https://images.unsplash.com/photo-1590766940554-634a7ed41450?q=80&w=1200',
      title: { hi: 'गुरु मंत्र', en: 'Guru Mantra' },
      content: {
        hi: 'गुरुर ब्रह्मा गुरुर विष्णु गुरुर देवो महेश्वरः।\nगुरुर साक्षात परब्रह्म तस्मै श्री गुरवे नमः॥',
        en: 'Gurur Brahma Gurur Vishnu Gurur Devo Maheshwarah\nGurur Sakshat Parabrahma Tasmai Shri Gurave Namah'
      }
    }
  ],
  strotam: [
    {
      deity: { hi: 'श्री शिव', en: 'Lord Shiva' },
      image: 'https://images.unsplash.com/photo-1582233479366-6d38bc390a08?q=80&w=1200',
      title: { hi: 'शिव तांडव स्तोत्रम्', en: 'Shiva Tandava Stotram' },
      content: {
        hi: 'जटाटवीगलज्जलप्रवाहपावितस्थले\nगलेऽवलम्ब्य लम्बितां भुजङ्गतुङ्गमालिकाम्।\nडमड्डमड्डमड्डमन्निनादवड्डमर्वयं\nचकार चण्डताण्डवं तनोतु नः शिवः शिवम॥',
        en: 'Jatatavigalajjala Pravahapavitasthale\nGaleavalambya Lambitam Bhujangatungamalikam\nDamad Damad Damad Daman Ninadavadamarvayam\nChakara Chandatandavam Tanotu Nah Shivah Shivam'
      }
    }
  ]
};

export const RASHIFAL_DATA: RashiData[] = [
  {
    id: 'aries',
    name: { hi: 'मेष', en: 'Aries' },
    sanskritName: 'Mesha',
    symbol: '♈',
    predictions: {
      daily: { hi: 'आज का दिन शुभ रहेगा, नए अवसर मिलेंगे।', en: 'The day will be auspicious, new opportunities will come.' },
      weekly: { hi: 'सप्ताह के अंत में लाभ की संभावना है।', en: 'Possibility of profit at the end of the week.' },
      monthly: { hi: 'करियर में सकारात्मक बदलाव आएंगे।', en: 'Positive changes in career are expected.' },
      yearly: { hi: 'यह वर्ष आध्यात्मिक उन्नति के लिए उत्तम है।', en: 'This year is great for spiritual progress.' }
    }
  }
];

export const KUMBH_MELA_DATA = {
  startDate: '2028-04-09',
  title: { hi: 'सिंहस्थ कुंभ महापर्व', en: 'Simhastha Kumbh Mahaparv' },
  subtitle: { hi: 'अमृत स्नान और दिव्य अनुभूति', en: 'Nectar Bath & Divine Experience' },
  description: { 
    hi: 'उज्जैन का सिंहस्थ कुंभ वह पावन समय है जब अमृत की बूंदें क्षिप्रा के तट पर गिरती हैं। यह मोक्ष प्राप्ति का महान अवसर है।', 
    en: 'Ujjain Simhastha Kumbh is that sacred time when drops of nectar fall on the banks of Kshipra. It is a great opportunity for liberation.' 
  }
};

export const DREAM_INTERPRETER_INFO = {
  title: { hi: 'स्वप्न विचार शास्त्र', en: 'Dream Interpreter' },
  subtitle: { hi: 'अपने अवचेतन मन के दिव्य संकेतों को समझें', en: 'Understand divine signals from your subconscious mind' }
};

export const ANUSHTHAN_INFO = {
  title: { hi: 'आभासी अनुष्ठान केंद्र', en: 'Virtual Anushthan Center' },
  subtitle: { hi: 'अपने घर से महाकाल के चरणों में संकल्प और पूजन करें', en: 'Perform Sankalp and Puja from your home at Mahakal\'s feet' }
};

export const PANCHANG_DATA = {
  tithi: { hi: 'शुक्ल पक्ष, पंचमी', en: 'Shukla Paksha, Panchami' },
  nakshatra: { hi: 'रोहिणी', en: 'Rohini' },
  yog: { hi: 'सिद्ध', en: 'Siddha' },
  rahukaal: '10:30 AM - 12:00 PM',
  sunrise: '06:15 AM',
  sunset: '06:45 PM'
};

export const TESTIMONIALS_DATA = [
  {
    id: 1,
    name: "Rajesh Kumar",
    location: "Mumbai",
    text: {
      hi: "पंडित जी द्वारा की गई काल सर्प दोष पूजा से मेरे जीवन में अद्भुत परिवर्तन आया। उज्जैन में व्यवस्था बहुत ही उत्तम थी।",
      en: "The Kaal Sarp Dosh Puja performed by Pandit Ji brought amazing changes in my life. The arrangements in Ujjain were excellent."
    },
    rating: 5
  },
  {
    id: 2,
    name: "Sarah Jenkins",
    location: "London, UK",
    text: {
      hi: "ऑनलाइन रुद्राभिषेक का अनुभव बहुत ही दिव्य था। वीडियो कॉल पर संकल्प और मंत्रोच्चार स्पष्ट सुनाई दे रहा था।",
      en: "The online Rudrabhishek experience was divine. Sankalp and chanting were clearly audible on the video call."
    },
    rating: 5
  },
  {
    id: 3,
    name: "Amit & Priya",
    location: "Bangalore",
    text: {
      hi: "विवाह बाधा निवारण पूजा के बाद हमारा रिश्ता तय हो गया। पंडित जी का मार्गदर्शन बहुत सटीक था।",
      en: "Our alliance was fixed after the Vivah Badha Nivaran Puja. Pandit Ji's guidance was very accurate."
    },
    rating: 5
  }
];

export const FESTIVALS_DATA = [
  { name: { hi: "महाशिवरात्रि", en: "Maha Shivratri" }, date: "8 March" },
  { name: { hi: "होली", en: "Holi" }, date: "25 March" },
  { name: { hi: "चैत्र नवरात्रि", en: "Chaitra Navratri" }, date: "9 April" },
  { name: { hi: "राम नवमी", en: "Ram Navami" }, date: "17 April" },
];
